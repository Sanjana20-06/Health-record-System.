// Mock data for the health records system

// Patient Medical History
export const medicalHistory = [
  {
    id: '1',
    patientId: '1',
    date: '2023-10-15',
    provider: 'Dr. Sarah Johnson',
    condition: 'Hypertension',
    notes: 'Patient presented with elevated blood pressure. Prescribed lisinopril 10mg daily.',
    followUp: '2023-11-15'
  },
  {
    id: '2',
    patientId: '1',
    date: '2023-08-22',
    provider: 'Dr. Michael Chen',
    condition: 'Annual Physical',
    notes: 'Routine examination. Patient is in good health overall. Recommended increased physical activity.',
    followUp: '2024-08-22'
  },
  {
    id: '3',
    patientId: '1',
    date: '2023-05-03',
    provider: 'Dr. Sarah Johnson',
    condition: 'Seasonal Allergies',
    notes: 'Patient experiencing nasal congestion and itchy eyes. Prescribed Claritin 10mg once daily as needed.',
    followUp: '2023-05-17'
  },
  {
    id: '4',
    patientId: '1',
    date: '2022-11-12',
    provider: 'Dr. Emily Rodriguez',
    condition: 'Influenza',
    notes: 'Patient presenting with fever, body aches, and fatigue. Tamiflu prescribed. Recommended rest and fluids.',
    followUp: '2022-11-19'
  }
];

// Prescriptions
export const prescriptions = [
  {
    id: '1',
    patientId: '1',
    medication: 'Lisinopril',
    dosage: '10mg',
    frequency: 'Once daily',
    startDate: '2023-10-15',
    endDate: '2024-04-15',
    refills: 5,
    prescribedBy: 'Dr. Sarah Johnson',
    status: 'Active',
    notes: 'Take in the morning with food.'
  },
  {
    id: '2',
    patientId: '1',
    medication: 'Claritin',
    dosage: '10mg',
    frequency: 'Once daily as needed',
    startDate: '2023-05-03',
    endDate: '2024-05-03',
    refills: 3,
    prescribedBy: 'Dr. Sarah Johnson',
    status: 'Active',
    notes: 'Take as needed for allergy symptoms.'
  },
  {
    id: '3',
    patientId: '1',
    medication: 'Tamiflu',
    dosage: '75mg',
    frequency: 'Twice daily',
    startDate: '2022-11-12',
    endDate: '2022-11-17',
    refills: 0,
    prescribedBy: 'Dr. Emily Rodriguez',
    status: 'Completed',
    notes: 'Complete full course of medication.'
  }
];

// Lab Reports
export const labReports = [
  {
    id: '1',
    patientId: '1',
    date: '2023-10-14',
    type: 'Blood Test',
    orderedBy: 'Dr. Sarah Johnson',
    results: [
      { name: 'Hemoglobin', value: '14.2', unit: 'g/dL', range: '13.5-17.5', status: 'normal' },
      { name: 'White Blood Cell Count', value: '7.8', unit: 'K/uL', range: '4.5-11.0', status: 'normal' },
      { name: 'Cholesterol', value: '210', unit: 'mg/dL', range: '<200', status: 'high' },
      { name: 'Glucose', value: '92', unit: 'mg/dL', range: '70-99', status: 'normal' }
    ],
    summary: 'Overall results within normal range except for slightly elevated cholesterol.'
  },
  {
    id: '2',
    patientId: '1',
    date: '2023-08-22',
    type: 'Urinalysis',
    orderedBy: 'Dr. Michael Chen',
    results: [
      { name: 'pH', value: '6.0', unit: '', range: '4.5-8.0', status: 'normal' },
      { name: 'Specific Gravity', value: '1.018', unit: '', range: '1.005-1.030', status: 'normal' },
      { name: 'Glucose', value: 'Negative', unit: '', range: 'Negative', status: 'normal' },
      { name: 'Protein', value: 'Negative', unit: '', range: 'Negative', status: 'normal' }
    ],
    summary: 'Normal urinalysis results.'
  },
  {
    id: '3',
    patientId: '1',
    date: '2023-01-05',
    type: 'Lipid Panel',
    orderedBy: 'Dr. Sarah Johnson',
    results: [
      { name: 'Total Cholesterol', value: '215', unit: 'mg/dL', range: '<200', status: 'high' },
      { name: 'HDL', value: '45', unit: 'mg/dL', range: '>40', status: 'normal' },
      { name: 'LDL', value: '135', unit: 'mg/dL', range: '<130', status: 'high' },
      { name: 'Triglycerides', value: '175', unit: 'mg/dL', range: '<150', status: 'high' }
    ],
    summary: 'Elevated cholesterol levels. Recommend lifestyle modifications and follow-up in 3 months.'
  }
];

// Appointments
export const appointments = [
  {
    id: '1',
    patientId: '1',
    providerId: '2',
    date: '2023-11-15',
    time: '10:00 AM',
    duration: 30,
    type: 'Follow-up',
    reason: 'Hypertension follow-up',
    status: 'Scheduled',
    location: 'Main Clinic, Room 305'
  },
  {
    id: '2',
    patientId: '1',
    providerId: '2',
    date: '2023-12-05',
    time: '2:30 PM',
    duration: 45,
    type: 'General Consultation',
    reason: 'Annual flu vaccination',
    status: 'Scheduled',
    location: 'Main Clinic, Room 210'
  },
  {
    id: '3',
    patientId: '1',
    providerId: '2',
    date: '2023-05-17',
    time: '9:15 AM',
    duration: 30,
    type: 'Follow-up',
    reason: 'Allergy follow-up',
    status: 'Completed',
    location: 'Main Clinic, Room 305',
    notes: 'Patient reports improvement in symptoms. Continue current medication.'
  }
];

// Messages
export const messages = [
  {
    id: '1',
    conversationId: '1',
    senderId: '1',
    receiverId: '2',
    timestamp: '2023-10-16T15:32:00Z',
    content: 'Hello Dr. Johnson, I\'ve been taking the new medication for a few days and experiencing some dizziness. Is this normal?',
    read: true
  },
  {
    id: '2',
    conversationId: '1',
    senderId: '2',
    receiverId: '1',
    timestamp: '2023-10-16T16:45:00Z',
    content: 'Hi John, some patients do experience mild dizziness when starting lisinopril. Try taking it at night before bed instead of in the morning. If the dizziness is severe or doesn\'t improve in a few days, please call our office.',
    read: true
  },
  {
    id: '3',
    conversationId: '1',
    senderId: '1',
    receiverId: '2',
    timestamp: '2023-10-17T09:20:00Z',
    content: 'Thank you Dr. Johnson, I\'ll try taking it at night and let you know how it goes.',
    read: true
  },
  {
    id: '4',
    conversationId: '1',
    senderId: '2',
    receiverId: '1',
    timestamp: '2023-10-17T10:05:00Z',
    content: 'Sounds good. Don\'t hesitate to reach out if you have any other concerns.',
    read: true
  },
  {
    id: '5',
    conversationId: '1',
    senderId: '1',
    receiverId: '2',
    timestamp: '2023-10-20T14:30:00Z',
    content: 'The dizziness has improved significantly since taking the medication at night. Thanks for the advice!',
    read: false
  }
];

// Conversations
export const conversations = [
  {
    id: '1',
    participants: ['1', '2'],
    lastMessageId: '5',
    lastMessageTimestamp: '2023-10-20T14:30:00Z',
    subject: 'Medication Side Effects'
  }
];

// Patient List for Healthcare Providers
export const patients = [
  {
    id: '1',
    firstName: 'John',
    lastName: 'Doe',
    dateOfBirth: '1985-05-15',
    gender: 'Male',
    email: 'patient@example.com',
    phone: '555-123-4567',
    address: '123 Main St, Anytown, USA',
    insuranceProvider: 'Blue Cross Blue Shield',
    insuranceNumber: 'BCBS12345678',
    primaryProvider: 'Dr. Sarah Johnson',
    emergencyContact: {
      name: 'Jane Doe',
      relationship: 'Spouse',
      phone: '555-987-6543'
    },
    allergies: ['Penicillin', 'Peanuts'],
    conditions: ['Hypertension', 'Seasonal Allergies']
  },
  {
    id: '3',
    firstName: 'Emma',
    lastName: 'Wilson',
    dateOfBirth: '1992-09-28',
    gender: 'Female',
    email: 'emma.wilson@example.com',
    phone: '555-222-3333',
    address: '789 Oak Dr, Anytown, USA',
    insuranceProvider: 'Aetna',
    insuranceNumber: 'AET98765432',
    primaryProvider: 'Dr. Sarah Johnson',
    emergencyContact: {
      name: 'Robert Wilson',
      relationship: 'Father',
      phone: '555-444-5555'
    },
    allergies: ['Sulfa Drugs'],
    conditions: ['Asthma', 'Eczema']
  },
  {
    id: '4',
    firstName: 'Michael',
    lastName: 'Brown',
    dateOfBirth: '1977-03-12',
    gender: 'Male',
    email: 'michael.brown@example.com',
    phone: '555-666-7777',
    address: '456 Pine St, Anytown, USA',
    insuranceProvider: 'UnitedHealthcare',
    insuranceNumber: 'UHC55667788',
    primaryProvider: 'Dr. Sarah Johnson',
    emergencyContact: {
      name: 'Susan Brown',
      relationship: 'Wife',
      phone: '555-888-9999'
    },
    allergies: ['Latex'],
    conditions: ['Type 2 Diabetes', 'Hyperlipidemia']
  }
];

// Health statistics for charts
export const healthStats = {
  bloodPressure: [
    { date: '2023-01-15', systolic: 142, diastolic: 90 },
    { date: '2023-02-15', systolic: 138, diastolic: 88 },
    { date: '2023-03-15', systolic: 135, diastolic: 87 },
    { date: '2023-04-15', systolic: 133, diastolic: 85 },
    { date: '2023-05-15', systolic: 130, diastolic: 84 },
    { date: '2023-06-15', systolic: 132, diastolic: 84 },
    { date: '2023-07-15', systolic: 129, diastolic: 82 },
    { date: '2023-08-15', systolic: 128, diastolic: 82 },
    { date: '2023-09-15', systolic: 125, diastolic: 80 },
    { date: '2023-10-15', systolic: 124, diastolic: 80 }
  ],
  weight: [
    { date: '2023-01-15', value: 185 },
    { date: '2023-02-15', value: 183 },
    { date: '2023-03-15', value: 181 },
    { date: '2023-04-15', value: 180 },
    { date: '2023-05-15', value: 178 },
    { date: '2023-06-15', value: 179 },
    { date: '2023-07-15', value: 177 },
    { date: '2023-08-15', value: 176 },
    { date: '2023-09-15', value: 175 },
    { date: '2023-10-15', value: 174 }
  ],
  bloodGlucose: [
    { date: '2023-01-15', value: 95 },
    { date: '2023-02-15', value: 97 },
    { date: '2023-03-15', value: 94 },
    { date: '2023-04-15', value: 92 },
    { date: '2023-05-15', value: 93 },
    { date: '2023-06-15', value: 95 },
    { date: '2023-07-15', value: 90 },
    { date: '2023-08-15', value: 91 },
    { date: '2023-09-15', value: 89 },
    { date: '2023-10-15', value: 92 }
  ],
  cholesterol: [
    { date: '2022-10-15', total: 220, hdl: 45, ldl: 145 },
    { date: '2023-01-15', total: 215, hdl: 46, ldl: 138 },
    { date: '2023-04-15', total: 210, hdl: 48, ldl: 135 },
    { date: '2023-07-15', total: 205, hdl: 49, ldl: 130 },
    { date: '2023-10-15', total: 200, hdl: 50, ldl: 125 }
  ]
};