import { Outlet } from 'react-router-dom';

const AuthLayout = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-500 to-secondary-600 flex flex-col">
      <div className="flex-grow flex items-center justify-center p-4">
        <div className="bg-white rounded-xl shadow-xl w-full max-w-md p-8 animate-fadeIn">
          <div className="text-center mb-8">
            <div className="flex justify-center mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary-500">
                <path d="M22 12h-4l-3 9L9 3l-3 9H2"></path>
              </svg>
            </div>
            <h2 className="text-2xl font-bold text-neutral-900">Health Records System</h2>
            <p className="text-neutral-600">Secure access to your health information</p>
          </div>
          
          <Outlet />
        </div>
      </div>
      
      <footer className="p-4 text-center text-white text-sm">
        <p>&copy; 2025 Health Records System. All rights reserved.</p>
        <p className="mt-1">
          <a href="#" className="underline hover:text-white/80 transition-colors">Privacy Policy</a>
          {' · '}
          <a href="#" className="underline hover:text-white/80 transition-colors">Terms of Service</a>
          {' · '}
          <a href="#" className="underline hover:text-white/80 transition-colors">HIPAA Compliance</a>
        </p>
      </footer>
    </div>
  );
};

export default AuthLayout;