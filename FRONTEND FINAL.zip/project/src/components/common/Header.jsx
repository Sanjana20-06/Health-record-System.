import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext.jsx';

const Header = () => {
  const { currentUser, logout } = useAuth();
  const navigate = useNavigate();
  const [showDropdown, setShowDropdown] = useState(false);
  
  const handleLogout = () => {
    logout();
    navigate('/login');
  };
  
  const toggleDropdown = () => {
    setShowDropdown(!showDropdown);
  };

  return (
    <header className="bg-white shadow-sm">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center">
          <Link to="/" className="flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary-500 mr-3">
              <path d="M22 12h-4l-3 9L9 3l-3 9H2"></path>
            </svg>
            <span className="text-xl font-semibold text-primary-700">Health Records</span>
          </Link>
        </div>
        
        <div className="flex items-center">
          {currentUser && (
            <>
              <div className="hidden md:flex mr-6 space-x-6">
                <Link to="/dashboard" className="text-neutral-700 hover:text-primary-500 transition-colors">
                  Dashboard
                </Link>
                {currentUser.role === 'patient' ? (
                  <>
                    <Link to="/medical-history" className="text-neutral-700 hover:text-primary-500 transition-colors">
                      Medical History
                    </Link>
                    <Link to="/prescriptions" className="text-neutral-700 hover:text-primary-500 transition-colors">
                      Prescriptions
                    </Link>
                    <Link to="/lab-reports" className="text-neutral-700 hover:text-primary-500 transition-colors">
                      Lab Results
                    </Link>
                  </>
                ) : (
                  <Link to="/patients" className="text-neutral-700 hover:text-primary-500 transition-colors">
                    Patients
                  </Link>
                )}
                <Link to="/appointments" className="text-neutral-700 hover:text-primary-500 transition-colors">
                  Appointments
                </Link>
                <Link to="/messages" className="text-neutral-700 hover:text-primary-500 transition-colors">
                  Messages
                </Link>
              </div>
              
              <div className="relative">
                <div className="flex items-center cursor-pointer" onClick={toggleDropdown}>
                  <div className="avatar avatar-sm mr-2">
                    {currentUser.profileImage ? (
                      <img 
                        src={currentUser.profileImage} 
                        alt={`${currentUser.firstName} ${currentUser.lastName}`} 
                      />
                    ) : (
                      <span>
                        {currentUser.firstName.charAt(0)}
                        {currentUser.lastName.charAt(0)}
                      </span>
                    )}
                  </div>
                  <span className="text-sm font-medium mr-1 hidden sm:inline">
                    {currentUser.firstName} {currentUser.lastName}
                  </span>
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M6 9l6 6 6-6"/>
                  </svg>
                </div>
                
                <div className={`dropdown-menu ${showDropdown ? 'show' : ''}`}>
                  <div className="py-2 px-4 border-b border-neutral-200">
                    <p className="text-sm font-medium">{currentUser.firstName} {currentUser.lastName}</p>
                    <p className="text-xs text-neutral-500">{currentUser.email}</p>
                  </div>
                  <Link to="/settings" className="dropdown-item" onClick={() => setShowDropdown(false)}>
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                      <circle cx="12" cy="12" r="3"></circle>
                      <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
                    </svg>
                    Settings
                  </Link>
                  <div className="dropdown-divider"></div>
                  <button className="dropdown-item text-error-600" onClick={handleLogout}>
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                      <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
                      <polyline points="16 17 21 12 16 7"></polyline>
                      <line x1="21" y1="12" x2="9" y2="12"></line>
                    </svg>
                    Logout
                  </button>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;