import { useEffect, useRef } from 'react';
import Chart from 'chart.js/auto';
import { format } from 'date-fns';

const HealthChart = ({ type, data, height = 300 }) => {
  const chartRef = useRef(null);
  const chartInstance = useRef(null);
  
  useEffect(() => {
    // Destroy previous chart if it exists
    if (chartInstance.current) {
      chartInstance.current.destroy();
    }
    
    if (!chartRef.current) return;
    
    const ctx = chartRef.current.getContext('2d');
    
    // Format dates for x-axis
    const formatDates = (dateStr) => {
      return format(new Date(dateStr), 'MMM d');
    };
    
    let config = {
      type: 'line',
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'top',
            align: 'end',
            labels: {
              usePointStyle: true,
              boxWidth: 6
            }
          },
          tooltip: {
            mode: 'index',
            intersect: false,
            backgroundColor: 'rgba(255, 255, 255, 0.9)',
            titleColor: '#333',
            bodyColor: '#666',
            borderColor: '#ddd',
            borderWidth: 1,
            padding: 10,
            boxPadding: 5,
            cornerRadius: 8,
            bodyFont: {
              family: "'Inter', sans-serif",
              size: 12
            },
            titleFont: {
              family: "'Inter', sans-serif",
              size: 14,
              weight: 'bold'
            }
          }
        },
        scales: {
          x: {
            grid: {
              display: false
            },
            ticks: {
              font: {
                family: "'Inter', sans-serif",
                size: 10
              }
            }
          },
          y: {
            beginAtZero: false,
            ticks: {
              font: {
                family: "'Inter', sans-serif",
                size: 10
              }
            },
            grid: {
              color: 'rgba(0, 0, 0, 0.05)'
            }
          }
        },
        elements: {
          line: {
            tension: 0.3
          },
          point: {
            radius: 3,
            hoverRadius: 5
          }
        }
      }
    };
    
    // Configure chart based on type
    switch (type) {
      case 'bloodPressure':
        config.data = {
          labels: data.map(d => formatDates(d.date)),
          datasets: [
            {
              label: 'Systolic',
              data: data.map(d => d.systolic),
              borderColor: '#EA4335',
              backgroundColor: 'rgba(234, 67, 53, 0.1)',
              fill: false
            },
            {
              label: 'Diastolic',
              data: data.map(d => d.diastolic),
              borderColor: '#0A6ED1',
              backgroundColor: 'rgba(10, 110, 209, 0.1)',
              fill: false
            }
          ]
        };
        config.options.scales.y.title = {
          display: true,
          text: 'mmHg'
        };
        break;
      
      case 'weight':
        config.data = {
          labels: data.map(d => formatDates(d.date)),
          datasets: [
            {
              label: 'Weight',
              data: data.map(d => d.value),
              borderColor: '#1992D4',
              backgroundColor: 'rgba(25, 146, 212, 0.1)',
              fill: true
            }
          ]
        };
        config.options.scales.y.title = {
          display: true,
          text: 'lbs'
        };
        break;
      
      case 'bloodGlucose':
        config.data = {
          labels: data.map(d => formatDates(d.date)),
          datasets: [
            {
              label: 'Blood Glucose',
              data: data.map(d => d.value),
              borderColor: '#FBBC05',
              backgroundColor: 'rgba(251, 188, 5, 0.1)',
              fill: true
            }
          ]
        };
        config.options.scales.y.title = {
          display: true,
          text: 'mg/dL'
        };
        break;
      
      case 'cholesterol':
        config.data = {
          labels: data.map(d => formatDates(d.date)),
          datasets: [
            {
              label: 'Total',
              data: data.map(d => d.total),
              borderColor: '#EA4335',
              backgroundColor: 'rgba(234, 67, 53, 0.1)',
              fill: false
            },
            {
              label: 'HDL',
              data: data.map(d => d.hdl),
              borderColor: '#34A853',
              backgroundColor: 'rgba(52, 168, 83, 0.1)',
              fill: false
            },
            {
              label: 'LDL',
              data: data.map(d => d.ldl),
              borderColor: '#FBBC05',
              backgroundColor: 'rgba(251, 188, 5, 0.1)',
              fill: false
            }
          ]
        };
        config.options.scales.y.title = {
          display: true,
          text: 'mg/dL'
        };
        break;
      
      default:
        break;
    }
    
    // Create chart
    chartInstance.current = new Chart(ctx, config);
    
    // Cleanup on unmount
    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [type, data]);

  return (
    <div style={{ height: `${height}px` }}>
      <canvas ref={chartRef}></canvas>
    </div>
  );
};

export default HealthChart;