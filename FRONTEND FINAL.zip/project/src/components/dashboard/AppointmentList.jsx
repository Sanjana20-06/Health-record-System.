import { useState } from 'react';
import { format } from 'date-fns';

const AppointmentList = ({ appointments }) => {
  const [activeTab, setActiveTab] = useState('upcoming');
  
  const upcomingAppointments = appointments.filter(
    (appointment) => appointment.status === 'Scheduled'
  );
  
  const pastAppointments = appointments.filter(
    (appointment) => appointment.status === 'Completed'
  );
  
  const formatDate = (dateString) => {
    return format(new Date(dateString), 'MMM d, yyyy');
  };
  
  return (
    <div className="card">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-xl font-semibold">Appointments</h3>
        <a href="/appointments" className="text-sm text-primary-500 hover:text-primary-600 flex items-center">
          View All
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="ml-1">
            <path d="M5 12h14"></path>
            <path d="M12 5l7 7-7 7"></path>
          </svg>
        </a>
      </div>
      
      <div className="tabs mb-4">
        <button 
          className={`tab ${activeTab === 'upcoming' ? 'active' : ''}`}
          onClick={() => setActiveTab('upcoming')}
        >
          Upcoming ({upcomingAppointments.length})
        </button>
        <button 
          className={`tab ${activeTab === 'past' ? 'active' : ''}`}
          onClick={() => setActiveTab('past')}
        >
          Past ({pastAppointments.length})
        </button>
      </div>
      
      <div className="space-y-4">
        {activeTab === 'upcoming' ? (
          upcomingAppointments.length > 0 ? (
            upcomingAppointments.map((appointment) => (
              <div key={appointment.id} className="p-4 border border-neutral-200 rounded-lg hover:bg-neutral-50 transition-colors">
                <div className="flex justify-between items-start">
                  <div>
                    <div className="flex items-center">
                      <div className="w-2 h-2 rounded-full bg-primary-500 mr-2"></div>
                      <span className="font-medium">{appointment.type}</span>
                    </div>
                    <p className="text-neutral-500 text-sm mt-1">{appointment.reason}</p>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-medium">{formatDate(appointment.date)}</div>
                    <div className="text-neutral-500 text-sm">{appointment.time}</div>
                  </div>
                </div>
                <div className="mt-3 flex justify-between items-center">
                  <div className="text-sm text-neutral-500">
                    {appointment.location}
                  </div>
                  <div className="flex space-x-2">
                    <button className="btn btn-sm btn-outline">Reschedule</button>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-6 text-neutral-500">
              No upcoming appointments scheduled
            </div>
          )
        ) : (
          pastAppointments.length > 0 ? (
            pastAppointments.map((appointment) => (
              <div key={appointment.id} className="p-4 border border-neutral-200 rounded-lg bg-neutral-50">
                <div className="flex justify-between items-start">
                  <div>
                    <div className="flex items-center">
                      <div className="w-2 h-2 rounded-full bg-neutral-400 mr-2"></div>
                      <span className="font-medium">{appointment.type}</span>
                    </div>
                    <p className="text-neutral-500 text-sm mt-1">{appointment.reason}</p>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-medium">{formatDate(appointment.date)}</div>
                    <div className="text-neutral-500 text-sm">{appointment.time}</div>
                  </div>
                </div>
                {appointment.notes && (
                  <div className="mt-3 text-sm">
                    <p className="text-neutral-600 italic">{appointment.notes}</p>
                  </div>
                )}
              </div>
            ))
          ) : (
            <div className="text-center py-6 text-neutral-500">
              No past appointments
            </div>
          )
        )}
      </div>
      
      <div className="mt-6 flex justify-center">
        <a href="/appointments/new" className="btn btn-primary">
          Schedule New Appointment
        </a>
      </div>
    </div>
  );
};

export default AppointmentList;