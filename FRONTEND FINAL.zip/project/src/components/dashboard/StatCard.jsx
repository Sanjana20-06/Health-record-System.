import { useEffect, useState } from 'react';

const StatCard = ({ title, value, icon, trend, trendValue, color = 'primary' }) => {
  const [animate, setAnimate] = useState(false);
  
  useEffect(() => {
    setAnimate(true);
    const timeout = setTimeout(() => setAnimate(false), 300);
    return () => clearTimeout(timeout);
  }, [value]);
  
  const getColorClass = () => {
    const colors = {
      primary: 'bg-primary-100 text-primary-700',
      secondary: 'bg-secondary-100 text-secondary-700',
      success: 'bg-success-100 text-success-700',
      warning: 'bg-warning-100 text-warning-700',
      error: 'bg-error-100 text-error-700'
    };
    
    return colors[color] || colors.primary;
  };
  
  const getTrendColor = () => {
    if (!trend) return '';
    return trend === 'up' ? 'text-success-500' : 'text-error-500';
  };
  
  const getTrendIcon = () => {
    if (!trend) return null;
    
    return trend === 'up' ? (
      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <polyline points="18 15 12 9 6 15"></polyline>
      </svg>
    ) : (
      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <polyline points="6 9 12 15 18 9"></polyline>
      </svg>
    );
  };

  return (
    <div className="card p-6">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-neutral-500 text-sm mb-1">{title}</p>
          <h4 className={`text-2xl font-bold ${animate ? 'animate-pulse' : ''}`}>
            {value}
          </h4>
          
          {trend && (
            <div className={`flex items-center mt-2 ${getTrendColor()}`}>
              {getTrendIcon()}
              <span className="text-sm ml-1">{trendValue}</span>
            </div>
          )}
        </div>
        
        <div className={`rounded-full p-3 ${getColorClass()}`}>
          {icon}
        </div>
      </div>
    </div>
  );
};

export default StatCard;