import { useEffect } from 'react';
import { Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { useAuth } from './contexts/AuthContext.jsx';

// Layouts
import DashboardLayout from './layouts/DashboardLayout.jsx';
import AuthLayout from './layouts/AuthLayout.jsx';

// Pages
import Login from './pages/auth/Login.jsx';
import Register from './pages/auth/Register.jsx';
import ForgotPassword from './pages/auth/ForgotPassword.jsx';
import PatientDashboard from './pages/patient/Dashboard.jsx';
import MedicalHistory from './pages/patient/MedicalHistory.jsx';
import Prescriptions from './pages/patient/Prescriptions.jsx';
import LabReports from './pages/patient/LabReports.jsx';
import Messages from './pages/shared/Messages.jsx';
import Appointments from './pages/shared/Appointments.jsx';
import ProviderDashboard from './pages/provider/Dashboard.jsx';
import PatientRecords from './pages/provider/PatientRecords.jsx';
import PatientDetail from './pages/provider/PatientDetail.jsx';
import Settings from './pages/shared/Settings.jsx';

// Utils
import ScrollToTop from './utils/ScrollToTop.jsx';

const App = () => {
  const { currentUser } = useAuth();
  const location = useLocation();

  useEffect(() => {
    document.title = getPageTitle(location.pathname);
  }, [location]);

  const getPageTitle = (pathname) => {
    const baseTitle = 'Health Records System';
    const path = pathname.split('/').filter(Boolean)[0];
    
    const titles = {
      'login': 'Login',
      'register': 'Create Account',
      'forgot-password': 'Reset Password',
      'dashboard': 'Dashboard',
      'medical-history': 'Medical History',
      'prescriptions': 'Prescriptions',
      'lab-reports': 'Lab Reports',
      'messages': 'Messages',
      'appointments': 'Appointments',
      'patients': 'Patient Records',
      'settings': 'Settings'
    };
    
    return titles[path] ? `${titles[path]} | ${baseTitle}` : baseTitle;
  };

  return (
    <>
      <ScrollToTop />
      <Routes>
        {/* Auth Routes */}
        <Route element={<AuthLayout />}>
          <Route path="/login" element={!currentUser ? <Login /> : <Navigate to="/dashboard" />} />
          <Route path="/register" element={!currentUser ? <Register /> : <Navigate to="/dashboard" />} />
          <Route path="/forgot-password" element={!currentUser ? <ForgotPassword /> : <Navigate to="/dashboard" />} />
        </Route>

        {/* Protected Routes */}
        <Route element={<DashboardLayout />}>
          <Route path="/" element={<Navigate to="/dashboard" />} />
          
          {/* Patient Routes */}
          <Route path="/dashboard" element={currentUser?.role === 'patient' ? <PatientDashboard /> : <ProviderDashboard />} />
          <Route path="/medical-history" element={<MedicalHistory />} />
          <Route path="/prescriptions" element={<Prescriptions />} />
          <Route path="/lab-reports" element={<LabReports />} />
          
          {/* Provider Routes */}
          <Route path="/patients" element={<PatientRecords />} />
          <Route path="/patients/:id" element={<PatientDetail />} />
          
          {/* Shared Routes */}
          <Route path="/messages" element={<Messages />} />
          <Route path="/appointments" element={<Appointments />} />
          <Route path="/settings" element={<Settings />} />
        </Route>
        
        {/* Not Found */}
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </>
  );
};

export default App;