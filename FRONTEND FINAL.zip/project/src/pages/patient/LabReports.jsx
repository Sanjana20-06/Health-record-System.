import { useState } from 'react';
import { labReports } from '../../data/mockData.js';
import { format } from 'date-fns';
import HealthChart from '../../components/dashboard/HealthChart.jsx';

const LabReports = () => {
  const [selectedReport, setSelectedReport] = useState(null);
  
  const formatDate = (dateString) => {
    return format(new Date(dateString), 'MMM d, yyyy');
  };
  
  const getStatusBadge = (status) => {
    switch (status) {
      case 'normal':
        return <span className="badge badge-success">Normal</span>;
      case 'high':
        return <span className="badge badge-error">High</span>;
      case 'low':
        return <span className="badge badge-warning">Low</span>;
      default:
        return <span className="badge badge-secondary">{status}</span>;
    }
  };
  
  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Lab Reports</h1>
        <p className="text-neutral-600">
          View and track your lab test results and diagnostic reports.
        </p>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <div className="card mb-6">
            <h3 className="text-xl font-semibold mb-4">Recent Tests</h3>
            <div className="space-y-3">
              {labReports.map((report) => (
                <div
                  key={report.id}
                  className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                    selectedReport?.id === report.id
                      ? 'border-primary-500 bg-primary-50'
                      : 'border-neutral-200 hover:border-primary-300'
                  }`}
                  onClick={() => setSelectedReport(report)}
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-medium">{report.type}</h4>
                      <p className="text-sm text-neutral-500">{formatDate(report.date)}</p>
                    </div>
                    <span className="badge badge-primary">Available</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="card">
            <h3 className="text-xl font-semibold mb-4">Actions</h3>
            <div className="space-y-3">
              <button className="btn btn-primary w-full">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                  <polyline points="7 10 12 15 17 10"></polyline>
                  <line x1="12" y1="15" x2="12" y2="3"></line>
                </svg>
                Download Reports
              </button>
              <button className="btn btn-outline w-full">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                  <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                  <polyline points="22,6 12,13 2,6"></polyline>
                </svg>
                Share with Provider
              </button>
              <button className="btn btn-outline w-full">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                  <polyline points="14 2 14 8 20 8"></polyline>
                  <line x1="16" y1="13" x2="8" y2="13"></line>
                  <line x1="16" y1="17" x2="8" y2="17"></line>
                  <polyline points="10 9 9 9 8 9"></polyline>
                </svg>
                Request New Test
              </button>
            </div>
          </div>
        </div>
        
        <div className="lg:col-span-2">
          {selectedReport ? (
            <div className="card animate-fadeIn">
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h2 className="text-2xl font-bold">{selectedReport.type}</h2>
                  <p className="text-neutral-500">
                    {formatDate(selectedReport.date)} • Ordered by {selectedReport.orderedBy}
                  </p>
                </div>
                <div className="flex space-x-2">
                  <button className="btn btn-sm btn-outline">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                      <polyline points="7 10 12 15 17 10"></polyline>
                      <line x1="12" y1="15" x2="12" y2="3"></line>
                    </svg>
                    Download
                  </button>
                  <button className="btn btn-sm btn-outline">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                      <circle cx="18" cy="5" r="3"></circle>
                      <circle cx="6" cy="12" r="3"></circle>
                      <circle cx="18" cy="19" r="3"></circle>
                      <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"></line>
                      <line x1="15.41" y1="6.51" x2="8.59" y2="10.49"></line>
                    </svg>
                    Share
                  </button>
                </div>
              </div>
              
              <div className="mb-6">
                <h3 className="text-lg font-semibold mb-3">Summary</h3>
                <p className="p-4 bg-neutral-50 rounded-lg">
                  {selectedReport.summary}
                </p>
              </div>
              
              <div className="mb-6">
                <h3 className="text-lg font-semibold mb-3">Results</h3>
                <div className="table-container">
                  <table className="table w-full">
                    <thead>
                      <tr>
                        <th>Test</th>
                        <th>Result</th>
                        <th>Reference Range</th>
                        <th>Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {selectedReport.results.map((result, index) => (
                        <tr key={index}>
                          <td className="font-medium">{result.name}</td>
                          <td>
                            {result.value} {result.unit && <span className="text-neutral-500">{result.unit}</span>}
                          </td>
                          <td className="text-neutral-500">{result.range}</td>
                          <td>{getStatusBadge(result.status)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
              
              {selectedReport.type === 'Lipid Panel' && (
                <div>
                  <h3 className="text-lg font-semibold mb-3">Trend</h3>
                  <div className="p-4 bg-white rounded-lg border border-neutral-200">
                    <HealthChart type="cholesterol" data={[
                      { date: '2022-10-15', total: 220, hdl: 45, ldl: 145 },
                      { date: '2023-01-15', total: 215, hdl: 46, ldl: 138 },
                      { date: '2023-04-15', total: 210, hdl: 48, ldl: 135 },
                      { date: '2023-07-15', total: 205, hdl: 49, ldl: 130 },
                      { date: '2023-10-15', total: 200, hdl: 50, ldl: 125 }
                    ]} />
                  </div>
                </div>
              )}
              
              {selectedReport.type === 'Blood Test' && (
                <div>
                  <h3 className="text-lg font-semibold mb-3">Trend</h3>
                  <div className="p-4 bg-white rounded-lg border border-neutral-200">
                    <HealthChart type="bloodGlucose" data={[
                      { date: '2023-01-15', value: 95 },
                      { date: '2023-02-15', value: 97 },
                      { date: '2023-03-15', value: 94 },
                      { date: '2023-04-15', value: 92 },
                      { date: '2023-05-15', value: 93 },
                      { date: '2023-06-15', value: 95 },
                      { date: '2023-07-15', value: 90 },
                      { date: '2023-08-15', value: 91 },
                      { date: '2023-09-15', value: 89 },
                      { date: '2023-10-15', value: 92 }
                    ]} />
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="card flex flex-col items-center justify-center py-16">
              <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-neutral-300 mb-4">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                <polyline points="14 2 14 8 20 8"></polyline>
                <line x1="16" y1="13" x2="8" y2="13"></line>
                <line x1="16" y1="17" x2="8" y2="17"></line>
                <polyline points="10 9 9 9 8 9"></polyline>
              </svg>
              <h3 className="text-xl font-medium mb-2">Select a Report</h3>
              <p className="text-neutral-500 text-center max-w-md">
                Choose a lab report from the list to view detailed results and track your health metrics over time.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default LabReports;