import { useState, useEffect } from 'react';
import { useAuth } from '../../contexts/AuthContext.jsx';
import StatCard from '../../components/dashboard/StatCard.jsx';
import AppointmentList from '../../components/dashboard/AppointmentList.jsx';
import HealthChart from '../../components/dashboard/HealthChart.jsx';
import { appointments, healthStats } from '../../data/mockData.js';
import { format } from 'date-fns';

const PatientDashboard = () => {
  const { currentUser } = useAuth();
  const [loading, setLoading] = useState(true);
  const [activeMetric, setActiveMetric] = useState('bloodPressure');
  
  useEffect(() => {
    // Simulate loading data
    const timer = setTimeout(() => {
      setLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, []);
  
  const today = new Date();
  
  if (loading) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="text-center">
          <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="animate-spin text-primary-500 mx-auto mb-4">
            <circle cx="12" cy="12" r="10"></circle>
            <path d="M12 6v6l4 2"></path>
          </svg>
          <p className="text-neutral-600">Loading your health dashboard...</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="animate-fadeIn">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Hi, {currentUser.firstName}!</h1>
        <p className="text-neutral-600">
          Welcome to your health dashboard. Here's your health overview as of {format(today, 'MMMM d, yyyy')}.
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard 
          title="Blood Pressure" 
          value="124/80 mmHg" 
          icon={
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 2v20M2 12h20M20 16H4M20 8H4"></path>
            </svg>
          }
          trend="down"
          trendValue="6% from last month"
          color="primary"
        />
        
        <StatCard 
          title="Weight" 
          value="174 lbs" 
          icon={
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="8" y1="3" x2="16" y2="3"></line>
              <line x1="12" y1="3" x2="12" y2="15"></line>
              <circle cx="12" cy="18" r="3"></circle>
            </svg>
          }
          trend="down"
          trendValue="2 lbs from last month"
          color="secondary"
        />
        
        <StatCard 
          title="Blood Glucose" 
          value="92 mg/dL" 
          icon={
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
              <circle cx="12" cy="14" r="4"></circle>
              <polygon points="14 2 14 8 20 8"></polygon>
            </svg>
          }
          color="success"
        />
        
        <StatCard 
          title="Cholesterol" 
          value="200 mg/dL" 
          icon={
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M22 12h-4l-3 9L9 3l-3 9H2"></path>
            </svg>
          }
          trend="down"
          trendValue="5% from last check"
          color="warning"
        />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div className="card lg:col-span-2">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-xl font-semibold">Health Trends</h3>
            <div className="flex space-x-2">
              <button 
                className={`px-3 py-1 text-sm rounded-full ${activeMetric === 'bloodPressure' ? 'bg-primary-100 text-primary-700' : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'}`}
                onClick={() => setActiveMetric('bloodPressure')}
              >
                Blood Pressure
              </button>
              <button 
                className={`px-3 py-1 text-sm rounded-full ${activeMetric === 'weight' ? 'bg-primary-100 text-primary-700' : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'}`}
                onClick={() => setActiveMetric('weight')}
              >
                Weight
              </button>
              <button 
                className={`px-3 py-1 text-sm rounded-full ${activeMetric === 'bloodGlucose' ? 'bg-primary-100 text-primary-700' : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'}`}
                onClick={() => setActiveMetric('bloodGlucose')}
              >
                Glucose
              </button>
              <button 
                className={`px-3 py-1 text-sm rounded-full ${activeMetric === 'cholesterol' ? 'bg-primary-100 text-primary-700' : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'}`}
                onClick={() => setActiveMetric('cholesterol')}
              >
                Cholesterol
              </button>
            </div>
          </div>
          
          <HealthChart 
            type={activeMetric}
            data={healthStats[activeMetric]}
          />
        </div>
        
        <div>
          <AppointmentList appointments={appointments} />
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="card">
          <h3 className="text-xl font-semibold mb-4">Recent Prescriptions</h3>
          <div className="space-y-4">
            <div className="p-4 border border-neutral-200 rounded-lg">
              <div className="flex justify-between">
                <div>
                  <h4 className="font-medium">Lisinopril 10mg</h4>
                  <p className="text-sm text-neutral-500">Take once daily</p>
                </div>
                <span className="badge badge-success">Active</span>
              </div>
              <div className="mt-2 text-sm">
                <p>Prescribed by Dr. Sarah Johnson</p>
                <p className="text-neutral-500">Refills: 5 remaining</p>
              </div>
            </div>
            
            <div className="p-4 border border-neutral-200 rounded-lg">
              <div className="flex justify-between">
                <div>
                  <h4 className="font-medium">Claritin 10mg</h4>
                  <p className="text-sm text-neutral-500">Take as needed</p>
                </div>
                <span className="badge badge-success">Active</span>
              </div>
              <div className="mt-2 text-sm">
                <p>Prescribed by Dr. Sarah Johnson</p>
                <p className="text-neutral-500">Refills: 3 remaining</p>
              </div>
            </div>
          </div>
          <div className="mt-4 text-center">
            <a href="/prescriptions" className="text-primary-500 text-sm hover:text-primary-600">
              View all prescriptions →
            </a>
          </div>
        </div>
        
        <div className="card">
          <h3 className="text-xl font-semibold mb-4">Recent Lab Results</h3>
          <div className="space-y-4">
            <div className="p-4 border border-neutral-200 rounded-lg">
              <div className="flex justify-between">
                <div>
                  <h4 className="font-medium">Blood Test</h4>
                  <p className="text-sm text-neutral-500">October 14, 2023</p>
                </div>
                <span className="badge badge-primary">Available</span>
              </div>
              <p className="mt-2 text-sm">
                Results show normal values with slightly elevated cholesterol.
              </p>
            </div>
            
            <div className="p-4 border border-neutral-200 rounded-lg">
              <div className="flex justify-between">
                <div>
                  <h4 className="font-medium">Urinalysis</h4>
                  <p className="text-sm text-neutral-500">August 22, 2023</p>
                </div>
                <span className="badge badge-primary">Available</span>
              </div>
              <p className="mt-2 text-sm">
                All results within normal range.
              </p>
            </div>
          </div>
          <div className="mt-4 text-center">
            <a href="/lab-reports" className="text-primary-500 text-sm hover:text-primary-600">
              View all lab results →
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PatientDashboard;