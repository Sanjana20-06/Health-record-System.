import { useState } from 'react';
import { medicalHistory } from '../../data/mockData.js';
import { format } from 'date-fns';

const MedicalHistory = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState('date');
  const [sortDirection, setSortDirection] = useState('desc');
  
  // Filter and sort records
  const filteredRecords = medicalHistory
    .filter(record => {
      const searchTermLower = searchTerm.toLowerCase();
      return (
        record.condition.toLowerCase().includes(searchTermLower) ||
        record.provider.toLowerCase().includes(searchTermLower) ||
        record.notes.toLowerCase().includes(searchTermLower)
      );
    })
    .sort((a, b) => {
      if (sortBy === 'date') {
        return sortDirection === 'asc'
          ? new Date(a.date) - new Date(b.date)
          : new Date(b.date) - new Date(a.date);
      } else if (sortBy === 'condition') {
        return sortDirection === 'asc'
          ? a.condition.localeCompare(b.condition)
          : b.condition.localeCompare(a.condition);
      } else if (sortBy === 'provider') {
        return sortDirection === 'asc'
          ? a.provider.localeCompare(b.provider)
          : b.provider.localeCompare(a.provider);
      }
      return 0;
    });
  
  const handleSort = (field) => {
    if (sortBy === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setSortDirection('asc');
    }
  };
  
  const getSortIcon = (field) => {
    if (sortBy !== field) return null;
    
    return sortDirection === 'asc' ? (
      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <polyline points="18 15 12 9 6 15"></polyline>
      </svg>
    ) : (
      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <polyline points="6 9 12 15 18 9"></polyline>
      </svg>
    );
  };
  
  const formatDate = (dateString) => {
    return format(new Date(dateString), 'MMM d, yyyy');
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Medical History</h1>
        <p className="text-neutral-600">
          View and track your complete medical history and conditions.
        </p>
      </div>
      
      <div className="card mb-8">
        <div className="flex flex-col md:flex-row justify-between mb-6">
          <div className="mb-4 md:mb-0 flex-grow md:mr-4">
            <div className="relative">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400">
                <circle cx="11" cy="11" r="8"></circle>
                <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
              </svg>
              <input
                type="text"
                placeholder="Search medical records..."
                className="pl-10 w-full"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          
          <div className="flex">
            <button className="btn btn-outline mr-2">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                <polyline points="7 10 12 15 17 10"></polyline>
                <line x1="12" y1="15" x2="12" y2="3"></line>
              </svg>
              Export
            </button>
            <button className="btn btn-primary">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                <line x1="12" y1="5" x2="12" y2="19"></line>
                <line x1="5" y1="12" x2="19" y2="12"></line>
              </svg>
              Add Record
            </button>
          </div>
        </div>
        
        <div className="table-container">
          <table className="table w-full">
            <thead>
              <tr>
                <th 
                  className="cursor-pointer" 
                  onClick={() => handleSort('date')}
                >
                  <div className="flex items-center">
                    Date
                    <span className="ml-1">{getSortIcon('date')}</span>
                  </div>
                </th>
                <th 
                  className="cursor-pointer" 
                  onClick={() => handleSort('condition')}
                >
                  <div className="flex items-center">
                    Condition
                    <span className="ml-1">{getSortIcon('condition')}</span>
                  </div>
                </th>
                <th 
                  className="cursor-pointer" 
                  onClick={() => handleSort('provider')}
                >
                  <div className="flex items-center">
                    Provider
                    <span className="ml-1">{getSortIcon('provider')}</span>
                  </div>
                </th>
                <th>Notes</th>
                <th>Follow-up</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {filteredRecords.map((record) => (
                <tr key={record.id}>
                  <td>{formatDate(record.date)}</td>
                  <td>{record.condition}</td>
                  <td>{record.provider}</td>
                  <td>
                    <div className="max-w-xs overflow-hidden overflow-ellipsis whitespace-nowrap">
                      {record.notes}
                    </div>
                  </td>
                  <td>{record.followUp ? formatDate(record.followUp) : 'None'}</td>
                  <td>
                    <button className="btn btn-sm btn-outline">
                      View
                    </button>
                  </td>
                </tr>
              ))}
              
              {filteredRecords.length === 0 && (
                <tr>
                  <td colSpan="6" className="text-center py-8 text-neutral-500">
                    No records found. Try adjusting your search.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        
        {filteredRecords.length > 0 && (
          <div className="pagination mt-6">
            <div className="pagination-item">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="15 18 9 12 15 6"></polyline>
              </svg>
            </div>
            <div className="pagination-item active">1</div>
            <div className="pagination-item">2</div>
            <div className="pagination-item">3</div>
            <div className="pagination-item">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="9 18 15 12 9 6"></polyline>
              </svg>
            </div>
          </div>
        )}
      </div>
      
      <div className="mb-8">
        <h2 className="text-2xl font-bold mb-4">Health Timeline</h2>
        <div className="relative pl-8 border-l-2 border-primary-200 space-y-8 py-4">
          {filteredRecords.map((record, index) => (
            <div key={record.id} className={`relative animate-fadeIn animation-delay-${index}`}>
              <div className="absolute -left-10 mt-1.5 w-4 h-4 rounded-full bg-primary-500"></div>
              <div className="card mb-0 hover:shadow-lg transition-shadow">
                <div className="flex justify-between mb-2">
                  <span className="text-neutral-500">{formatDate(record.date)}</span>
                  <span className="badge badge-primary">{record.condition}</span>
                </div>
                <h4 className="text-lg font-semibold mb-2">{record.provider}</h4>
                <p className="text-neutral-700">{record.notes}</p>
                {record.followUp && (
                  <div className="mt-4 pt-4 border-t border-neutral-200">
                    <div className="flex items-center text-sm">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 text-primary-500">
                        <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                        <line x1="16" y1="2" x2="16" y2="6"></line>
                        <line x1="8" y1="2" x2="8" y2="6"></line>
                        <line x1="3" y1="10" x2="21" y2="10"></line>
                      </svg>
                      Follow-up: {formatDate(record.followUp)}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default MedicalHistory;