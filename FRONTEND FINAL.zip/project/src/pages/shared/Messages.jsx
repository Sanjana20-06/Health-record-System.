import { useState, useEffect } from 'react';
import { messages, conversations } from '../../data/mockData.js';
import { useAuth } from '../../contexts/AuthContext.jsx';
import { format } from 'date-fns';

const Messages = () => {
  const { currentUser } = useAuth();
  const [selectedConversation, setSelectedConversation] = useState(null);
  const [newMessage, setNewMessage] = useState('');
  const [conversationList, setConversationList] = useState([]);
  const [conversationMessages, setConversationMessages] = useState([]);
  
  useEffect(() => {
    // Prepare conversations with participant info
    const convos = conversations.map(convo => {
      // Find the other participant (not current user)
      const otherParticipantId = convo.participants.find(id => id !== currentUser.id);
      
      // Mock user data (in a real app, we'd fetch this)
      const mockUsers = {
        '1': { id: '1', firstName: 'John', lastName: 'Doe', role: 'patient' },
        '2': { id: '2', firstName: 'Sarah', lastName: 'Johnson', role: 'provider' }
      };
      
      const otherParticipant = mockUsers[otherParticipantId];
      
      // Find last message
      const lastMessage = messages.find(msg => msg.id === convo.lastMessageId);
      
      return {
        ...convo,
        otherParticipant,
        lastMessage
      };
    });
    
    setConversationList(convos);
    
    // Select first conversation by default if available
    if (convos.length > 0 && !selectedConversation) {
      handleSelectConversation(convos[0]);
    }
  }, [currentUser.id]);
  
  const handleSelectConversation = (conversation) => {
    setSelectedConversation(conversation);
    
    // Get messages for this conversation
    const conversationMsgs = messages.filter(
      msg => msg.conversationId === conversation.id
    );
    
    setConversationMessages(conversationMsgs);
  };
  
  const handleSendMessage = (e) => {
    e.preventDefault();
    
    if (!newMessage.trim() || !selectedConversation) return;
    
    // Create a new message (in a real app, this would be sent to an API)
    const newMsg = {
      id: Date.now().toString(),
      conversationId: selectedConversation.id,
      senderId: currentUser.id,
      receiverId: selectedConversation.otherParticipant.id,
      timestamp: new Date().toISOString(),
      content: newMessage,
      read: false
    };
    
    // Update conversation messages
    setConversationMessages([...conversationMessages, newMsg]);
    
    // Update last message in conversation list
    setConversationList(prevList => 
      prevList.map(convo => 
        convo.id === selectedConversation.id
          ? { ...convo, lastMessage: newMsg }
          : convo
      )
    );
    
    // Clear input
    setNewMessage('');
  };
  
  const formatMessageTime = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    
    // If today, show time only
    if (format(date, 'yyyy-MM-dd') === format(now, 'yyyy-MM-dd')) {
      return format(date, 'h:mm a');
    }
    
    // If this year, show month and day
    if (format(date, 'yyyy') === format(now, 'yyyy')) {
      return format(date, 'MMM d');
    }
    
    // Otherwise show full date
    return format(date, 'MMM d, yyyy');
  };

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-3xl font-bold mb-2">Messages</h1>
        <p className="text-neutral-600">
          Secure communication with your healthcare providers.
        </p>
      </div>
      
      <div className="card p-0 overflow-hidden">
        <div className="grid grid-cols-1 md:grid-cols-3">
          {/* Conversation List */}
          <div className="border-r border-neutral-200">
            <div className="p-4 border-b border-neutral-200">
              <div className="relative">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400">
                  <circle cx="11" cy="11" r="8"></circle>
                  <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                </svg>
                <input
                  type="text"
                  placeholder="Search conversations..."
                  className="pl-10 w-full"
                />
              </div>
            </div>
            
            <div className="overflow-y-auto" style={{ maxHeight: '600px' }}>
              {conversationList.map((conversation) => (
                <div
                  key={conversation.id}
                  className={`p-4 border-b border-neutral-200 cursor-pointer transition-colors ${
                    selectedConversation?.id === conversation.id
                      ? 'bg-primary-50'
                      : 'hover:bg-neutral-50'
                  }`}
                  onClick={() => handleSelectConversation(conversation)}
                >
                  <div className="flex items-start">
                    <div className="avatar avatar-md mr-3">
                      {conversation.otherParticipant?.firstName ? (
                        <span>
                          {conversation.otherParticipant.firstName.charAt(0)}
                          {conversation.otherParticipant.lastName.charAt(0)}
                        </span>
                      ) : (
                        <span>?</span>
                      )}
                    </div>
                    <div className="flex-grow min-w-0">
                      <div className="flex justify-between items-start">
                        <h4 className="font-medium truncate">
                          {conversation.otherParticipant?.firstName} {conversation.otherParticipant?.lastName}
                        </h4>
                        <span className="text-xs text-neutral-500 whitespace-nowrap ml-2">
                          {conversation.lastMessage ? formatMessageTime(conversation.lastMessage.timestamp) : ''}
                        </span>
                      </div>
                      <p className="text-sm text-neutral-600 truncate">
                        {conversation.lastMessage?.content}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
              
              {conversationList.length === 0 && (
                <div className="p-6 text-center text-neutral-500">
                  No conversations found
                </div>
              )}
            </div>
          </div>
          
          {/* Message Content */}
          <div className="md:col-span-2 flex flex-col" style={{ height: '600px' }}>
            {selectedConversation ? (
              <>
                {/* Conversation Header */}
                <div className="p-4 border-b border-neutral-200 flex items-center">
                  <div className="avatar avatar-md mr-3">
                    <span>
                      {selectedConversation.otherParticipant.firstName.charAt(0)}
                      {selectedConversation.otherParticipant.lastName.charAt(0)}
                    </span>
                  </div>
                  <div>
                    <h4 className="font-medium">
                      {selectedConversation.otherParticipant.firstName} {selectedConversation.otherParticipant.lastName}
                    </h4>
                    <p className="text-xs text-neutral-500">
                      {selectedConversation.otherParticipant.role === 'provider' ? 'Healthcare Provider' : 'Patient'}
                    </p>
                  </div>
                </div>
                
                {/* Messages */}
                <div className="flex-grow overflow-y-auto p-4 space-y-4">
                  {conversationMessages.map((msg) => {
                    const isCurrentUser = msg.senderId === currentUser.id;
                    
                    return (
                      <div
                        key={msg.id}
                        className={`flex ${isCurrentUser ? 'justify-end' : 'justify-start'}`}
                      >
                        <div
                          className={`max-w-[70%] p-3 rounded-lg ${
                            isCurrentUser
                              ? 'bg-primary-500 text-white'
                              : 'bg-neutral-100 text-neutral-800'
                          }`}
                        >
                          <p className="text-sm">{msg.content}</p>
                          <p className={`text-xs mt-1 ${isCurrentUser ? 'text-primary-100' : 'text-neutral-500'}`}>
                            {formatMessageTime(msg.timestamp)}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
                
                {/* Message Input */}
                <div className="p-4 border-t border-neutral-200">
                  <form onSubmit={handleSendMessage} className="flex">
                    <input
                      type="text"
                      placeholder="Type a message..."
                      className="flex-grow mr-2"
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                    />
                    <button
                      type="submit"
                      className="btn btn-primary px-4"
                      disabled={!newMessage.trim()}
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <line x1="22" y1="2" x2="11" y2="13"></line>
                        <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
                      </svg>
                    </button>
                  </form>
                </div>
              </>
            ) : (
              <div className="flex-grow flex flex-col items-center justify-center p-6 text-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-neutral-300 mb-4">
                  <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                </svg>
                <h3 className="text-xl font-medium mb-2">No Conversation Selected</h3>
                <p className="text-neutral-500 max-w-md">
                  Select a conversation from the list to view messages or start a new conversation.
                </p>
                <button className="btn btn-primary mt-4">
                  Start New Conversation
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Messages;