import { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext.jsx';

const Settings = () => {
  const { currentUser, updateProfile } = useAuth();
  const [activeTab, setActiveTab] = useState('profile');
  
  const [profile, setProfile] = useState({
    firstName: currentUser.firstName || '',
    lastName: currentUser.lastName || '',
    email: currentUser.email || '',
    phone: currentUser.phone || '',
    address: currentUser.address || '',
    dateOfBirth: currentUser.dateOfBirth || '',
  });
  
  const [notification, setNotification] = useState({
    emailAppointments: true,
    emailPrescriptions: true,
    emailLabResults: true,
    emailMessages: true,
    smsAppointments: true,
    smsPrescriptions: false,
    smsLabResults: false,
    smsMessages: true,
  });
  
  const [privacy, setPrivacy] = useState({
    shareDataWithProvider: true,
    allowResearch: false,
    allowThirdParty: false,
  });
  
  const [security, setSecurity] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });
  
  const [message, setMessage] = useState({ text: '', type: '' });
  
  const handleProfileChange = (e) => {
    const { name, value } = e.target;
    setProfile({ ...profile, [name]: value });
  };
  
  const handleNotificationChange = (e) => {
    const { name, checked } = e.target;
    setNotification({ ...notification, [name]: checked });
  };
  
  const handlePrivacyChange = (e) => {
    const { name, checked } = e.target;
    setPrivacy({ ...privacy, [name]: checked });
  };
  
  const handleSecurityChange = (e) => {
    const { name, value } = e.target;
    setSecurity({ ...security, [name]: value });
  };
  
  const handleProfileSubmit = async (e) => {
    e.preventDefault();
    
    try {
      await updateProfile(profile);
      setMessage({ text: 'Profile updated successfully!', type: 'success' });
      
      // Clear message after 3 seconds
      setTimeout(() => {
        setMessage({ text: '', type: '' });
      }, 3000);
    } catch (err) {
      setMessage({ text: err.message, type: 'error' });
    }
  };
  
  const handlePasswordSubmit = async (e) => {
    e.preventDefault();
    
    if (security.newPassword !== security.confirmPassword) {
      return setMessage({ text: 'Passwords do not match', type: 'error' });
    }
    
    try {
      // In a real app, we would call an API to change the password
      setMessage({ text: 'Password updated successfully!', type: 'success' });
      setSecurity({ currentPassword: '', newPassword: '', confirmPassword: '' });
      
      // Clear message after 3 seconds
      setTimeout(() => {
        setMessage({ text: '', type: '' });
      }, 3000);
    } catch (err) {
      setMessage({ text: err.message, type: 'error' });
    }
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Settings</h1>
        <p className="text-neutral-600">
          Manage your account settings and preferences.
        </p>
      </div>
      
      {message.text && (
        <div className={`alert ${message.type === 'success' ? 'alert-success' : 'alert-error'} mb-6`}>
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="alert-icon">
            {message.type === 'success' ? (
              <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
            ) : (
              <circle cx="12" cy="12" r="10"></circle>
            )}
            {message.type === 'success' ? (
              <polyline points="22 4 12 14.01 9 11.01"></polyline>
            ) : (
              <>
                <line x1="12" y1="8" x2="12" y2="12"></line>
                <line x1="12" y1="16" x2="12.01" y2="16"></line>
              </>
            )}
          </svg>
          {message.text}
        </div>
      )}
      
      <div className="card">
        <div className="tabs mb-6">
          <button 
            className={`tab ${activeTab === 'profile' ? 'active' : ''}`}
            onClick={() => setActiveTab('profile')}
          >
            Profile
          </button>
          <button 
            className={`tab ${activeTab === 'notification' ? 'active' : ''}`}
            onClick={() => setActiveTab('notification')}
          >
            Notifications
          </button>
          <button 
            className={`tab ${activeTab === 'privacy' ? 'active' : ''}`}
            onClick={() => setActiveTab('privacy')}
          >
            Privacy
          </button>
          <button 
            className={`tab ${activeTab === 'security' ? 'active' : ''}`}
            onClick={() => setActiveTab('security')}
          >
            Security
          </button>
        </div>
        
        {activeTab === 'profile' && (
          <div className="animate-fadeIn">
            <div className="mb-6 flex flex-col sm:flex-row items-center">
              <div className="avatar avatar-lg mr-6 mb-4 sm:mb-0">
                {currentUser.profileImage ? (
                  <img src={currentUser.profileImage} alt={`${currentUser.firstName} ${currentUser.lastName}`} />
                ) : (
                  <span className="text-xl">
                    {currentUser.firstName?.charAt(0)}
                    {currentUser.lastName?.charAt(0)}
                  </span>
                )}
              </div>
              
              <div>
                <h3 className="text-xl font-semibold mb-1">
                  {currentUser.firstName} {currentUser.lastName}
                </h3>
                <p className="text-neutral-500 mb-2">{currentUser.email}</p>
                <button className="btn btn-sm btn-outline">
                  Change Photo
                </button>
              </div>
            </div>
            
            <form onSubmit={handleProfileSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="firstName" className="block text-sm font-medium text-neutral-700 mb-1">
                    First Name
                  </label>
                  <input
                    id="firstName"
                    name="firstName"
                    type="text"
                    value={profile.firstName}
                    onChange={handleProfileChange}
                    className="w-full"
                  />
                </div>
                
                <div>
                  <label htmlFor="lastName" className="block text-sm font-medium text-neutral-700 mb-1">
                    Last Name
                  </label>
                  <input
                    id="lastName"
                    name="lastName"
                    type="text"
                    value={profile.lastName}
                    onChange={handleProfileChange}
                    className="w-full"
                  />
                </div>
                
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-neutral-700 mb-1">
                    Email
                  </label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    value={profile.email}
                    onChange={handleProfileChange}
                    className="w-full"
                  />
                </div>
                
                <div>
                  <label htmlFor="phone" className="block text-sm font-medium text-neutral-700 mb-1">
                    Phone
                  </label>
                  <input
                    id="phone"
                    name="phone"
                    type="tel"
                    value={profile.phone}
                    onChange={handleProfileChange}
                    className="w-full"
                  />
                </div>
                
                <div className="md:col-span-2">
                  <label htmlFor="address" className="block text-sm font-medium text-neutral-700 mb-1">
                    Address
                  </label>
                  <input
                    id="address"
                    name="address"
                    type="text"
                    value={profile.address}
                    onChange={handleProfileChange}
                    className="w-full"
                  />
                </div>
                
                <div>
                  <label htmlFor="dateOfBirth" className="block text-sm font-medium text-neutral-700 mb-1">
                    Date of Birth
                  </label>
                  <input
                    id="dateOfBirth"
                    name="dateOfBirth"
                    type="date"
                    value={profile.dateOfBirth}
                    onChange={handleProfileChange}
                    className="w-full"
                  />
                </div>
              </div>
              
              <div className="flex justify-end">
                <button type="submit" className="btn btn-primary">
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        )}
        
        {activeTab === 'notification' && (
          <div className="animate-fadeIn">
            <p className="mb-6 text-neutral-600">
              Manage how you receive notifications about appointments, prescriptions, lab results, and messages.
            </p>
            
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold mb-4">Email Notifications</h3>
                <div className="space-y-3">
                  <div className="flex items-center">
                    <input
                      id="emailAppointments"
                      name="emailAppointments"
                      type="checkbox"
                      checked={notification.emailAppointments}
                      onChange={handleNotificationChange}
                      className="h-4 w-4"
                    />
                    <label htmlFor="emailAppointments" className="ml-2">
                      Appointment reminders and updates
                    </label>
                  </div>
                  
                  <div className="flex items-center">
                    <input
                      id="emailPrescriptions"
                      name="emailPrescriptions"
                      type="checkbox"
                      checked={notification.emailPrescriptions}
                      onChange={handleNotificationChange}
                      className="h-4 w-4"
                    />
                    <label htmlFor="emailPrescriptions" className="ml-2">
                      Prescription refills and updates
                    </label>
                  </div>
                  
                  <div className="flex items-center">
                    <input
                      id="emailLabResults"
                      name="emailLabResults"
                      type="checkbox"
                      checked={notification.emailLabResults}
                      onChange={handleNotificationChange}
                      className="h-4 w-4"
                    />
                    <label htmlFor="emailLabResults" className="ml-2">
                      Lab result availability
                    </label>
                  </div>
                  
                  <div className="flex items-center">
                    <input
                      id="emailMessages"
                      name="emailMessages"
                      type="checkbox"
                      checked={notification.emailMessages}
                      onChange={handleNotificationChange}
                      className="h-4 w-4"
                    />
                    <label htmlFor="emailMessages" className="ml-2">
                      New messages from healthcare providers
                    </label>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold mb-4">SMS Notifications</h3>
                <div className="space-y-3">
                  <div className="flex items-center">
                    <input
                      id="smsAppointments"
                      name="smsAppointments"
                      type="checkbox"
                      checked={notification.smsAppointments}
                      onChange={handleNotificationChange}
                      className="h-4 w-4"
                    />
                    <label htmlFor="smsAppointments" className="ml-2">
                      Appointment reminders and updates
                    </label>
                  </div>
                  
                  <div className="flex items-center">
                    <input
                      id="smsPrescriptions"
                      name="smsPrescriptions"
                      type="checkbox"
                      checked={notification.smsPrescriptions}
                      onChange={handleNotificationChange}
                      className="h-4 w-4"
                    />
                    <label htmlFor="smsPrescriptions" className="ml-2">
                      Prescription refills and updates
                    </label>
                  </div>
                  
                  <div className="flex items-center">
                    <input
                      id="smsLabResults"
                      name="smsLabResults"
                      type="checkbox"
                      checked={notification.smsLabResults}
                      onChange={handleNotificationChange}
                      className="h-4 w-4"
                    />
                    <label htmlFor="smsLabResults" className="ml-2">
                      Lab result availability
                    </label>
                  </div>
                  
                  <div className="flex items-center">
                    <input
                      id="smsMessages"
                      name="smsMessages"
                      type="checkbox"
                      checked={notification.smsMessages}
                      onChange={handleNotificationChange}
                      className="h-4 w-4"
                    />
                    <label htmlFor="smsMessages" className="ml-2">
                      New messages from healthcare providers
                    </label>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end">
                <button className="btn btn-primary">
                  Save Changes
                </button>
              </div>
            </div>
          </div>
        )}
        
        {activeTab === 'privacy' && (
          <div className="animate-fadeIn">
            <p className="mb-6 text-neutral-600">
              Control how your health information is shared and used.
            </p>
            
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold mb-4">Data Sharing</h3>
                <div className="space-y-4">
                  <div className="p-4 border border-neutral-200 rounded-lg">
                    <div className="flex items-start">
                      <input
                        id="shareDataWithProvider"
                        name="shareDataWithProvider"
                        type="checkbox"
                        checked={privacy.shareDataWithProvider}
                        onChange={handlePrivacyChange}
                        className="h-4 w-4 mt-1"
                      />
                      <div className="ml-2">
                        <label htmlFor="shareDataWithProvider" className="font-medium">
                          Share data with healthcare providers
                        </label>
                        <p className="text-sm text-neutral-600 mt-1">
                          Allow your healthcare providers to access your medical records, prescriptions, and lab results to provide better care.
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="p-4 border border-neutral-200 rounded-lg">
                    <div className="flex items-start">
                      <input
                        id="allowResearch"
                        name="allowResearch"
                        type="checkbox"
                        checked={privacy.allowResearch}
                        onChange={handlePrivacyChange}
                        className="h-4 w-4 mt-1"
                      />
                      <div className="ml-2">
                        <label htmlFor="allowResearch" className="font-medium">
                          Anonymous data for research
                        </label>
                        <p className="text-sm text-neutral-600 mt-1">
                          Allow anonymized health data to be used for medical research and improving healthcare services. Your personal identifying information will never be shared.
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="p-4 border border-neutral-200 rounded-lg">
                    <div className="flex items-start">
                      <input
                        id="allowThirdParty"
                        name="allowThirdParty"
                        type="checkbox"
                        checked={privacy.allowThirdParty}
                        onChange={handlePrivacyChange}
                        className="h-4 w-4 mt-1"
                      />
                      <div className="ml-2">
                        <label htmlFor="allowThirdParty" className="font-medium">
                          Third-party data sharing
                        </label>
                        <p className="text-sm text-neutral-600 mt-1">
                          Allow your data to be shared with trusted third-party partners to provide additional services or improve existing ones.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold mb-4">Privacy Controls</h3>
                <div className="p-4 bg-neutral-50 rounded-lg">
                  <p className="text-sm mb-4">
                    You can request a copy of your data or request data deletion at any time.
                  </p>
                  <div className="flex space-x-3">
                    <button className="btn btn-outline btn-sm">
                      Request Data Copy
                    </button>
                    <button className="btn btn-error btn-sm">
                      Request Data Deletion
                    </button>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end">
                <button className="btn btn-primary">
                  Save Changes
                </button>
              </div>
            </div>
          </div>
        )}
        
        {activeTab === 'security' && (
          <div className="animate-fadeIn">
            <p className="mb-6 text-neutral-600">
              Manage your account security settings and password.
            </p>
            
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold mb-4">Change Password</h3>
                <form onSubmit={handlePasswordSubmit} className="space-y-4">
                  <div>
                    <label htmlFor="currentPassword" className="block text-sm font-medium text-neutral-700 mb-1">
                      Current Password
                    </label>
                    <input
                      id="currentPassword"
                      name="currentPassword"
                      type="password"
                      value={security.currentPassword}
                      onChange={handleSecurityChange}
                      className="w-full"
                      required
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="newPassword" className="block text-sm font-medium text-neutral-700 mb-1">
                      New Password
                    </label>
                    <input
                      id="newPassword"
                      name="newPassword"
                      type="password"
                      value={security.newPassword}
                      onChange={handleSecurityChange}
                      className="w-full"
                      required
                    />
                    <p className="mt-1 text-xs text-neutral-500">
                      Password must be at least 8 characters long with a mix of letters, numbers, and special characters.
                    </p>
                  </div>
                  
                  <div>
                    <label htmlFor="confirmPassword" className="block text-sm font-medium text-neutral-700 mb-1">
                      Confirm New Password
                    </label>
                    <input
                      id="confirmPassword"
                      name="confirmPassword"
                      type="password"
                      value={security.confirmPassword}
                      onChange={handleSecurityChange}
                      className="w-full"
                      required
                    />
                  </div>
                  
                  <div className="flex justify-end">
                    <button type="submit" className="btn btn-primary">
                      Update Password
                    </button>
                  </div>
                </form>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold mb-4">Two-Factor Authentication</h3>
                <div className="p-4 border border-neutral-200 rounded-lg">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="font-medium">Enhance your account security</p>
                      <p className="text-sm text-neutral-600 mt-1">
                        Add an extra layer of security to your account by enabling two-factor authentication.
                      </p>
                    </div>
                    <button className="btn btn-primary">
                      Enable 2FA
                    </button>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold mb-4">Login Sessions</h3>
                <div className="p-4 border border-neutral-200 rounded-lg">
                  <div className="mb-4">
                    <p className="font-medium">Current Session</p>
                    <div className="flex items-center mt-2">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-success-500 mr-2">
                        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                        <polyline points="22 4 12 14.01 9 11.01"></polyline>
                      </svg>
                      <span className="text-sm">This Device • Active Now</span>
                    </div>
                  </div>
                  
                  <div className="flex justify-end">
                    <button className="btn btn-outline btn-sm text-error-600">
                      Logout from All Devices
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Settings;