import { useState } from 'react';
import { appointments } from '../../data/mockData.js';
import { format, addDays, getDay, startOfWeek, addWeeks, subWeeks } from 'date-fns';

const Appointments = () => {
  const [activeTab, setActiveTab] = useState('upcoming');
  const [currentDate, setCurrentDate] = useState(new Date());
  const [currentWeek, setCurrentWeek] = useState(startOfWeek(new Date(), { weekStartsOn: 0 }));
  const [showModal, setShowModal] = useState(false);
  
  const upcomingAppointments = appointments.filter(
    (appointment) => appointment.status === 'Scheduled'
  );
  
  const pastAppointments = appointments.filter(
    (appointment) => appointment.status === 'Completed'
  );
  
  const handleNextWeek = () => {
    setCurrentWeek(addWeeks(currentWeek, 1));
  };
  
  const handlePrevWeek = () => {
    setCurrentWeek(subWeeks(currentWeek, 1));
  };
  
  const formatDate = (dateString) => {
    return format(new Date(dateString), 'MMM d, yyyy');
  };
  
  const formatTime = (timeString) => {
    return timeString;
  };
  
  const renderWeekDays = () => {
    const days = [];
    const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    
    for (let i = 0; i < 7; i++) {
      const day = addDays(currentWeek, i);
      const isToday = format(day, 'yyyy-MM-dd') === format(new Date(), 'yyyy-MM-dd');
      
      days.push(
        <div key={i} className={`text-center p-3 ${isToday ? 'bg-primary-50 rounded-lg' : ''}`}>
          <p className="text-sm text-neutral-500">{dayNames[getDay(day)]}</p>
          <p className={`text-lg font-medium ${isToday ? 'text-primary-600' : ''}`}>
            {format(day, 'd')}
          </p>
        </div>
      );
    }
    
    return days;
  };
  
  const renderTimeSlots = () => {
    const times = ['9:00 AM', '10:00 AM', '11:00 AM', '12:00 PM', '1:00 PM', '2:00 PM', '3:00 PM', '4:00 PM'];
    
    return times.map((time, index) => (
      <div key={index} className="grid grid-cols-8 border-t border-neutral-200">
        <div className="p-2 text-right pr-4 text-sm text-neutral-500">
          {time}
        </div>
        {[0, 1, 2, 3, 4, 5, 6].map((dayOffset) => {
          const day = addDays(currentWeek, dayOffset);
          const dateStr = format(day, 'yyyy-MM-dd');
          
          // Check if there's an appointment at this time slot
          const appointmentAtSlot = upcomingAppointments.find(
            (a) => format(new Date(a.date), 'yyyy-MM-dd') === dateStr && a.time === time
          );
          
          return (
            <div 
              key={dayOffset} 
              className={`p-2 border-l border-neutral-200 min-h-[60px] ${appointmentAtSlot ? 'bg-primary-50' : ''}`}
            >
              {appointmentAtSlot && (
                <div className="p-1 text-xs rounded bg-primary-100 text-primary-800">
                  {appointmentAtSlot.reason}
                </div>
              )}
            </div>
          );
        })}
      </div>
    ));
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Appointments</h1>
        <p className="text-neutral-600">
          Schedule and manage your healthcare appointments.
        </p>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div className="card lg:col-span-2">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-xl font-semibold">Calendar</h3>
            <div className="flex space-x-2">
              <button className="btn btn-sm btn-outline" onClick={handlePrevWeek}>
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="15 18 9 12 15 6"></polyline>
                </svg>
              </button>
              <button className="btn btn-sm btn-outline" onClick={() => setCurrentWeek(startOfWeek(new Date(), { weekStartsOn: 0 }))}>
                Today
              </button>
              <button className="btn btn-sm btn-outline" onClick={handleNextWeek}>
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="9 18 15 12 9 6"></polyline>
                </svg>
              </button>
            </div>
          </div>
          
          <div className="mb-4">
            <h4 className="font-medium mb-2">
              {format(currentWeek, 'MMMM yyyy')}
            </h4>
            <div className="grid grid-cols-8 gap-1">
              <div className="p-3"></div>
              {renderWeekDays()}
            </div>
          </div>
          
          <div className="overflow-x-auto">
            <div className="min-w-[800px]">
              {renderTimeSlots()}
            </div>
          </div>
        </div>
        
        <div>
          <div className="card mb-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-semibold">Upcoming</h3>
              <button 
                className="btn btn-primary"
                onClick={() => setShowModal(true)}
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                  <line x1="12" y1="5" x2="12" y2="19"></line>
                  <line x1="5" y1="12" x2="19" y2="12"></line>
                </svg>
                New
              </button>
            </div>
            
            <div className="space-y-3">
              {upcomingAppointments.length > 0 ? (
                upcomingAppointments.map((appointment) => (
                  <div key={appointment.id} className="p-3 border border-neutral-200 rounded-lg hover:border-primary-300 transition-colors">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-medium">{appointment.reason}</p>
                        <p className="text-sm text-neutral-500">{formatDate(appointment.date)} • {formatTime(appointment.time)}</p>
                      </div>
                      <span className="badge badge-primary">{appointment.type}</span>
                    </div>
                    <p className="text-sm mt-2">{appointment.location}</p>
                  </div>
                ))
              ) : (
                <p className="text-center text-neutral-500 py-4">No upcoming appointments</p>
              )}
            </div>
          </div>
          
          <div className="card">
            <h3 className="text-xl font-semibold mb-4">Recent</h3>
            <div className="space-y-3">
              {pastAppointments.length > 0 ? (
                pastAppointments.map((appointment) => (
                  <div key={appointment.id} className="p-3 border border-neutral-200 bg-neutral-50 rounded-lg">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-medium">{appointment.reason}</p>
                        <p className="text-sm text-neutral-500">{formatDate(appointment.date)} • {formatTime(appointment.time)}</p>
                      </div>
                      <span className="badge badge-secondary">Completed</span>
                    </div>
                    {appointment.notes && (
                      <p className="text-sm mt-2 italic">{appointment.notes}</p>
                    )}
                  </div>
                ))
              ) : (
                <p className="text-center text-neutral-500 py-4">No past appointments</p>
              )}
            </div>
          </div>
        </div>
      </div>
      
      {/* New Appointment Modal */}
      {showModal && (
        <div className="modal-backdrop show">
          <div className="modal">
            <div className="modal-header">
              <h3 className="modal-title">Schedule New Appointment</h3>
              <button className="modal-close" onClick={() => setShowModal(false)}>×</button>
            </div>
            <div className="modal-body">
              <form className="space-y-4">
                <div>
                  <label htmlFor="appointmentType" className="block text-sm font-medium text-neutral-700 mb-1">
                    Appointment Type
                  </label>
                  <select
                    id="appointmentType"
                    className="w-full px-3 py-2 border border-neutral-300 rounded-md"
                  >
                    <option value="checkup">General Check-up</option>
                    <option value="followup">Follow-up</option>
                    <option value="consultation">Consultation</option>
                    <option value="procedure">Procedure</option>
                  </select>
                </div>
                
                <div>
                  <label htmlFor="provider" className="block text-sm font-medium text-neutral-700 mb-1">
                    Healthcare Provider
                  </label>
                  <select
                    id="provider"
                    className="w-full px-3 py-2 border border-neutral-300 rounded-md"
                  >
                    <option value="dr-johnson">Dr. Sarah Johnson</option>
                    <option value="dr-chen">Dr. Michael Chen</option>
                    <option value="dr-rodriguez">Dr. Emily Rodriguez</option>
                  </select>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="date" className="block text-sm font-medium text-neutral-700 mb-1">
                      Date
                    </label>
                    <input
                      id="date"
                      type="date"
                      className="w-full px-3 py-2 border border-neutral-300 rounded-md"
                      min={format(new Date(), 'yyyy-MM-dd')}
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="time" className="block text-sm font-medium text-neutral-700 mb-1">
                      Time
                    </label>
                    <select
                      id="time"
                      className="w-full px-3 py-2 border border-neutral-300 rounded-md"
                    >
                      <option value="9:00 AM">9:00 AM</option>
                      <option value="10:00 AM">10:00 AM</option>
                      <option value="11:00 AM">11:00 AM</option>
                      <option value="1:00 PM">1:00 PM</option>
                      <option value="2:00 PM">2:00 PM</option>
                      <option value="3:00 PM">3:00 PM</option>
                      <option value="4:00 PM">4:00 PM</option>
                    </select>
                  </div>
                </div>
                
                <div>
                  <label htmlFor="reason" className="block text-sm font-medium text-neutral-700 mb-1">
                    Reason for Visit
                  </label>
                  <textarea
                    id="reason"
                    rows="3"
                    className="w-full px-3 py-2 border border-neutral-300 rounded-md"
                    placeholder="Please describe the reason for your visit"
                  ></textarea>
                </div>
                
                <div>
                  <label htmlFor="insurance" className="block text-sm font-medium text-neutral-700 mb-1">
                    Insurance Information
                  </label>
                  <select
                    id="insurance"
                    className="w-full px-3 py-2 border border-neutral-300 rounded-md"
                  >
                    <option value="blue-cross">Blue Cross Blue Shield</option>
                    <option value="aetna">Aetna</option>
                    <option value="united">UnitedHealthcare</option>
                    <option value="cigna">Cigna</option>
                    <option value="self-pay">Self Pay</option>
                  </select>
                </div>
              </form>
            </div>
            <div className="modal-footer">
              <button className="btn btn-outline" onClick={() => setShowModal(false)}>
                Cancel
              </button>
              <button className="btn btn-primary">
                Schedule Appointment
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Appointments;