import { useState } from 'react';
import { Link } from 'react-router-dom';
import { patients } from '../../data/mockData.js';
import { format } from 'date-fns';

const PatientRecords = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState('lastName');
  const [sortDirection, setSortDirection] = useState('asc');
  
  // Filter and sort patients
  const filteredPatients = patients
    .filter(patient => {
      const searchTermLower = searchTerm.toLowerCase();
      return (
        patient.firstName.toLowerCase().includes(searchTermLower) ||
        patient.lastName.toLowerCase().includes(searchTermLower) ||
        patient.email.toLowerCase().includes(searchTermLower) ||
        (patient.conditions && patient.conditions.some(c => c.toLowerCase().includes(searchTermLower)))
      );
    })
    .sort((a, b) => {
      if (sortBy === 'lastName') {
        return sortDirection === 'asc'
          ? a.lastName.localeCompare(b.lastName)
          : b.lastName.localeCompare(a.lastName);
      } else if (sortBy === 'firstName') {
        return sortDirection === 'asc'
          ? a.firstName.localeCompare(b.firstName)
          : b.firstName.localeCompare(a.firstName);
      } else if (sortBy === 'dateOfBirth') {
        return sortDirection === 'asc'
          ? new Date(a.dateOfBirth) - new Date(b.dateOfBirth)
          : new Date(b.dateOfBirth) - new Date(a.dateOfBirth);
      }
      return 0;
    });
  
  const handleSort = (field) => {
    if (sortBy === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setSortDirection('asc');
    }
  };
  
  const getSortIcon = (field) => {
    if (sortBy !== field) return null;
    
    return sortDirection === 'asc' ? (
      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <polyline points="18 15 12 9 6 15"></polyline>
      </svg>
    ) : (
      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <polyline points="6 9 12 15 18 9"></polyline>
      </svg>
    );
  };
  
  const formatDate = (dateString) => {
    return format(new Date(dateString), 'MMM d, yyyy');
  };
  
  const getAge = (dateOfBirth) => {
    const today = new Date();
    const birthDate = new Date(dateOfBirth);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    
    return age;
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Patient Records</h1>
        <p className="text-neutral-600">
          View and manage your patient records and medical information.
        </p>
      </div>
      
      <div className="card mb-8">
        <div className="flex flex-col md:flex-row justify-between mb-6">
          <div className="mb-4 md:mb-0 flex-grow md:mr-4">
            <div className="relative">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400">
                <circle cx="11" cy="11" r="8"></circle>
                <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
              </svg>
              <input
                type="text"
                placeholder="Search patients by name, email, or conditions..."
                className="pl-10 w-full"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          
          <div className="flex">
            <button className="btn btn-outline mr-2">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                <polyline points="7 10 12 15 17 10"></polyline>
                <line x1="12" y1="15" x2="12" y2="3"></line>
              </svg>
              Export
            </button>
            <button className="btn btn-primary">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                <line x1="12" y1="5" x2="12" y2="19"></line>
                <line x1="5" y1="12" x2="19" y2="12"></line>
              </svg>
              Add Patient
            </button>
          </div>
        </div>
        
        <div className="table-container">
          <table className="table w-full">
            <thead>
              <tr>
                <th 
                  className="cursor-pointer" 
                  onClick={() => handleSort('lastName')}
                >
                  <div className="flex items-center">
                    Name
                    <span className="ml-1">{getSortIcon('lastName')}</span>
                  </div>
                </th>
                <th 
                  className="cursor-pointer" 
                  onClick={() => handleSort('dateOfBirth')}
                >
                  <div className="flex items-center">
                    Date of Birth
                    <span className="ml-1">{getSortIcon('dateOfBirth')}</span>
                  </div>
                </th>
                <th>Contact</th>
                <th>Conditions</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredPatients.map((patient) => (
                <tr key={patient.id}>
                  <td>
                    <div className="flex items-center">
                      <div className="avatar avatar-sm mr-3">
                        <span>
                          {patient.firstName.charAt(0)}
                          {patient.lastName.charAt(0)}
                        </span>
                      </div>
                      <div>
                        <div className="font-medium">{patient.lastName}, {patient.firstName}</div>
                        <div className="text-sm text-neutral-500">{getAge(patient.dateOfBirth)} years</div>
                      </div>
                    </div>
                  </td>
                  <td>{formatDate(patient.dateOfBirth)}</td>
                  <td>
                    <div>{patient.email}</div>
                    <div className="text-sm text-neutral-500">{patient.phone}</div>
                  </td>
                  <td>
                    <div className="flex flex-wrap gap-1">
                      {patient.conditions.map((condition, index) => (
                        <span key={index} className="badge badge-primary">{condition}</span>
                      ))}
                    </div>
                  </td>
                  <td>
                    <div className="flex space-x-2">
                      <Link to={`/patients/${patient.id}`} className="btn btn-sm btn-primary">
                        View
                      </Link>
                      <button className="btn btn-sm btn-outline">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                          <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                        </svg>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              
              {filteredPatients.length === 0 && (
                <tr>
                  <td colSpan="5" className="text-center py-8 text-neutral-500">
                    No patients found. Try adjusting your search.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        
        {filteredPatients.length > 0 && (
          <div className="pagination mt-6">
            <div className="pagination-item">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="15 18 9 12 15 6"></polyline>
              </svg>
            </div>
            <div className="pagination-item active">1</div>
            <div className="pagination-item">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="9 18 15 12 9 6"></polyline>
              </svg>
            </div>
          </div>
        )}
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="card">
          <h3 className="text-xl font-semibold mb-4">Recent Activity</h3>
          <div className="space-y-4">
            <div className="p-3 border-l-4 border-primary-500">
              <p className="font-medium">Updated treatment plan</p>
              <p className="text-sm text-neutral-500">For John Doe • 2 hours ago</p>
            </div>
            <div className="p-3 border-l-4 border-secondary-500">
              <p className="font-medium">Added new lab results</p>
              <p className="text-sm text-neutral-500">For Emma Wilson • Yesterday</p>
            </div>
            <div className="p-3 border-l-4 border-success-500">
              <p className="font-medium">Created new prescription</p>
              <p className="text-sm text-neutral-500">For Michael Brown • 2 days ago</p>
            </div>
          </div>
        </div>
        
        <div className="card">
          <h3 className="text-xl font-semibold mb-4">Patient Statistics</h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-sm text-neutral-500">Total Patients</p>
                <p className="text-2xl font-semibold">{patients.length}</p>
              </div>
              <div className="w-12 h-12 rounded-full bg-primary-100 flex items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary-600">
                  <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                  <circle cx="9" cy="7" r="4"></circle>
                  <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                  <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                </svg>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-neutral-500">Average Age</p>
                <p className="text-xl font-semibold">42</p>
              </div>
              <div>
                <p className="text-sm text-neutral-500">Gender Ratio</p>
                <p className="text-xl font-semibold">1:2</p>
              </div>
              <div>
                <p className="text-sm text-neutral-500">New This Month</p>
                <p className="text-xl font-semibold">3</p>
              </div>
              <div>
                <p className="text-sm text-neutral-500">Active Care Plans</p>
                <p className="text-xl font-semibold">7</p>
              </div>
            </div>
          </div>
        </div>
        
        <div className="card">
          <h3 className="text-xl font-semibold mb-4">Common Conditions</h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span>Hypertension</span>
              <div className="w-1/2 bg-neutral-200 rounded-full h-2">
                <div className="bg-primary-500 h-2 rounded-full" style={{ width: '65%' }}></div>
              </div>
              <span className="text-sm">65%</span>
            </div>
            <div className="flex justify-between items-center">
              <span>Diabetes</span>
              <div className="w-1/2 bg-neutral-200 rounded-full h-2">
                <div className="bg-primary-500 h-2 rounded-full" style={{ width: '45%' }}></div>
              </div>
              <span className="text-sm">45%</span>
            </div>
            <div className="flex justify-between items-center">
              <span>Asthma</span>
              <div className="w-1/2 bg-neutral-200 rounded-full h-2">
                <div className="bg-primary-500 h-2 rounded-full" style={{ width: '30%' }}></div>
              </div>
              <span className="text-sm">30%</span>
            </div>
            <div className="flex justify-between items-center">
              <span>Allergies</span>
              <div className="w-1/2 bg-neutral-200 rounded-full h-2">
                <div className="bg-primary-500 h-2 rounded-full" style={{ width: '25%' }}></div>
              </div>
              <span className="text-sm">25%</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PatientRecords;