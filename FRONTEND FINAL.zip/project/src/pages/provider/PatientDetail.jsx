import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { patients, medicalHistory, prescriptions, labReports, appointments } from '../../data/mockData.js';
import { format } from 'date-fns';
import HealthChart from '../../components/dashboard/HealthChart.jsx';
import { healthStats } from '../../data/mockData.js';

const PatientDetail = () => {
  const { id } = useParams();
  const [patient, setPatient] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');
  const [activeMetric, setActiveMetric] = useState('bloodPressure');
  
  useEffect(() => {
    // Find patient by ID
    const foundPatient = patients.find(p => p.id === id);
    
    if (foundPatient) {
      // Get patient-specific data
      const patientMedicalHistory = medicalHistory.filter(record => record.patientId === id);
      const patientPrescriptions = prescriptions.filter(prescription => prescription.patientId === id);
      const patientLabReports = labReports.filter(report => report.patientId === id);
      const patientAppointments = appointments.filter(appointment => appointment.patientId === id);
      
      setPatient({
        ...foundPatient,
        medicalHistory: patientMedicalHistory,
        prescriptions: patientPrescriptions,
        labReports: patientLabReports,
        appointments: patientAppointments
      });
    }
    
    setLoading(false);
  }, [id]);
  
  const formatDate = (dateString) => {
    return format(new Date(dateString), 'MMM d, yyyy');
  };
  
  const getAge = (dateOfBirth) => {
    const today = new Date();
    const birthDate = new Date(dateOfBirth);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    
    return age;
  };
  
  if (loading) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="text-center">
          <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="animate-spin text-primary-500 mx-auto mb-4">
            <circle cx="12" cy="12" r="10"></circle>
            <path d="M12 6v6l4 2"></path>
          </svg>
          <p className="text-neutral-600">Loading patient data...</p>
        </div>
      </div>
    );
  }
  
  if (!patient) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="text-center">
          <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-neutral-300 mx-auto mb-4">
            <circle cx="12" cy="12" r="10"></circle>
            <line x1="12" y1="8" x2="12" y2="12"></line>
            <line x1="12" y1="16" x2="12.01" y2="16"></line>
          </svg>
          <h2 className="text-2xl font-bold mb-2">Patient Not Found</h2>
          <p className="text-neutral-600 mb-6">
            The patient you're looking for doesn't exist or you don't have access.
          </p>
          <Link to="/patients" className="btn btn-primary">
            Return to Patient List
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-6">
        <Link to="/patients" className="text-primary-500 flex items-center hover:text-primary-600 transition-colors">
          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
            <line x1="19" y1="12" x2="5" y2="12"></line>
            <polyline points="12 19 5 12 12 5"></polyline>
          </svg>
          Back to Patient List
        </Link>
      </div>
      
      <div className="card mb-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between">
          <div className="flex items-center mb-4 md:mb-0">
            <div className="avatar avatar-lg mr-4">
              <span className="text-xl">
                {patient.firstName.charAt(0)}
                {patient.lastName.charAt(0)}
              </span>
            </div>
            <div>
              <h1 className="text-2xl font-bold">
                {patient.firstName} {patient.lastName}
              </h1>
              <div className="text-neutral-600">
                {getAge(patient.dateOfBirth)} years old • Born {formatDate(patient.dateOfBirth)}
              </div>
            </div>
          </div>
          
          <div className="flex flex-wrap gap-2">
            <button className="btn btn-primary">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
              </svg>
              Edit Record
            </button>
            <button className="btn btn-outline">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                <line x1="16" y1="2" x2="16" y2="6"></line>
                <line x1="8" y1="2" x2="8" y2="6"></line>
                <line x1="3" y1="10" x2="21" y2="10"></line>
              </svg>
              Schedule
            </button>
            <button className="btn btn-outline">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                <polyline points="22,6 12,13 2,6"></polyline>
              </svg>
              Message
            </button>
          </div>
        </div>
      </div>
      
      <div className="tabs mb-6">
        <button 
          className={`tab ${activeTab === 'overview' ? 'active' : ''}`}
          onClick={() => setActiveTab('overview')}
        >
          Overview
        </button>
        <button 
          className={`tab ${activeTab === 'history' ? 'active' : ''}`}
          onClick={() => setActiveTab('history')}
        >
          Medical History
        </button>
        <button 
          className={`tab ${activeTab === 'prescriptions' ? 'active' : ''}`}
          onClick={() => setActiveTab('prescriptions')}
        >
          Prescriptions
        </button>
        <button 
          className={`tab ${activeTab === 'lab' ? 'active' : ''}`}
          onClick={() => setActiveTab('lab')}
        >
          Lab Reports
        </button>
        <button 
          className={`tab ${activeTab === 'appointments' ? 'active' : ''}`}
          onClick={() => setActiveTab('appointments')}
        >
          Appointments
        </button>
      </div>
      
      {activeTab === 'overview' && (
        <div className="animate-fadeIn">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="card">
              <h3 className="text-lg font-semibold mb-4">Patient Information</h3>
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-neutral-500">Contact Information</p>
                  <div className="mt-1">
                    <div className="flex items-center mb-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 text-neutral-500">
                        <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                      </svg>
                      <span>{patient.phone}</span>
                    </div>
                    <div className="flex items-center mb-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 text-neutral-500">
                        <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                        <polyline points="22,6 12,13 2,6"></polyline>
                      </svg>
                      <span>{patient.email}</span>
                    </div>
                    <div className="flex items-start mb-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 mt-1 text-neutral-500">
                        <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                        <circle cx="12" cy="10" r="3"></circle>
                      </svg>
                      <span>{patient.address}</span>
                    </div>
                  </div>
                </div>
                
                <div>
                  <p className="text-sm text-neutral-500">Insurance</p>
                  <div className="mt-1">
                    <p className="font-medium">{patient.insuranceProvider}</p>
                    <p className="text-sm">Policy #: {patient.insuranceNumber}</p>
                  </div>
                </div>
                
                <div>
                  <p className="text-sm text-neutral-500">Emergency Contact</p>
                  <div className="mt-1">
                    <p className="font-medium">{patient.emergencyContact.name}</p>
                    <p className="text-sm">{patient.emergencyContact.relationship}</p>
                    <p className="text-sm">{patient.emergencyContact.phone}</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="md:col-span-2 card">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold">Health Status</h3>
                <div className="flex space-x-2">
                  <button 
                    className={`px-3 py-1 text-sm rounded-full ${activeMetric === 'bloodPressure' ? 'bg-primary-100 text-primary-700' : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'}`}
                    onClick={() => setActiveMetric('bloodPressure')}
                  >
                    BP
                  </button>
                  <button 
                    className={`px-3 py-1 text-sm rounded-full ${activeMetric === 'weight' ? 'bg-primary-100 text-primary-700' : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'}`}
                    onClick={() => setActiveMetric('weight')}
                  >
                    Weight
                  </button>
                  <button 
                    className={`px-3 py-1 text-sm rounded-full ${activeMetric === 'bloodGlucose' ? 'bg-primary-100 text-primary-700' : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'}`}
                    onClick={() => setActiveMetric('bloodGlucose')}
                  >
                    Glucose
                  </button>
                </div>
              </div>
              
              <HealthChart 
                type={activeMetric}
                data={healthStats[activeMetric]}
              />
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
                <div>
                  <p className="text-sm text-neutral-500">Latest BP</p>
                  <p className="text-lg font-semibold">124/80 mmHg</p>
                </div>
                <div>
                  <p className="text-sm text-neutral-500">Latest Weight</p>
                  <p className="text-lg font-semibold">174 lbs</p>
                </div>
                <div>
                  <p className="text-sm text-neutral-500">Latest Glucose</p>
                  <p className="text-lg font-semibold">92 mg/dL</p>
                </div>
                <div>
                  <p className="text-sm text-neutral-500">BMI</p>
                  <p className="text-lg font-semibold">24.5</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div className="card">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold">Current Conditions</h3>
                <button className="btn btn-sm btn-outline">Add Condition</button>
              </div>
              
              <div className="space-y-3">
                {patient.conditions.map((condition, index) => (
                  <div key={index} className="p-3 border border-neutral-200 rounded-lg">
                    <div className="flex justify-between items-start">
                      <div>
                        <span className="font-medium">{condition}</span>
                      </div>
                      <div className="flex space-x-1">
                        <button className="p-1 text-neutral-400 hover:text-primary-500">
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                            <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                          </svg>
                        </button>
                      </div>
                    </div>
                    <div className="mt-2 flex text-sm">
                      <span className="text-neutral-500 mr-2">Since:</span>
                      <span>June 2023</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="card">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold">Allergies</h3>
                <button className="btn btn-sm btn-outline">Add Allergy</button>
              </div>
              
              <div className="space-y-3">
                {patient.allergies.map((allergy, index) => (
                  <div key={index} className="p-3 border border-neutral-200 rounded-lg">
                    <div className="flex justify-between items-start">
                      <div>
                        <span className="font-medium">{allergy}</span>
                      </div>
                      <div className="flex space-x-1">
                        <span className="badge badge-error">Severe</span>
                        <button className="p-1 text-neutral-400 hover:text-primary-500">
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                            <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                          </svg>
                        </button>
                      </div>
                    </div>
                    <div className="mt-2 flex text-sm">
                      <span className="text-neutral-500 mr-2">Reaction:</span>
                      <span>Anaphylaxis</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-1 gap-6">
            <div className="card">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold">Notes</h3>
                <button className="btn btn-sm btn-outline">Add Note</button>
              </div>
              
              <div className="p-4 border border-neutral-200 rounded-lg">
                <div className="flex justify-between">
                  <span className="font-medium">Treatment Plan Notes</span>
                  <span className="text-sm text-neutral-500">June 15, 2023</span>
                </div>
                <p className="mt-2">
                  Patient is responding well to hypertension medication. Blood pressure has been steadily decreasing over the past 3 months. 
                  Will continue current medication regimen and follow up in 3 months for re-assessment.
                </p>
                <div className="mt-3 text-sm text-neutral-500">
                  Added by Dr. Sarah Johnson
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {activeTab === 'history' && (
        <div className="animate-fadeIn">
          <div className="flex justify-between mb-6">
            <h3 className="text-xl font-semibold">Medical History</h3>
            <button className="btn btn-primary">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                <line x1="12" y1="5" x2="12" y2="19"></line>
                <line x1="5" y1="12" x2="19" y2="12"></line>
              </svg>
              Add Record
            </button>
          </div>
          
          <div className="card mb-8">
            <div className="table-container">
              <table className="table w-full">
                <thead>
                  <tr>
                    <th>Date</th>
                    <th>Condition</th>
                    <th>Provider</th>
                    <th>Notes</th>
                    <th>Follow-up</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {patient.medicalHistory.map((record) => (
                    <tr key={record.id}>
                      <td>{formatDate(record.date)}</td>
                      <td>{record.condition}</td>
                      <td>{record.provider}</td>
                      <td>
                        <div className="max-w-xs overflow-hidden overflow-ellipsis whitespace-nowrap">
                          {record.notes}
                        </div>
                      </td>
                      <td>{record.followUp ? formatDate(record.followUp) : 'None'}</td>
                      <td>
                        <button className="btn btn-sm btn-outline">
                          View
                        </button>
                      </td>
                    </tr>
                  ))}
                  
                  {patient.medicalHistory.length === 0 && (
                    <tr>
                      <td colSpan="6" className="text-center py-8 text-neutral-500">
                        No medical history records found.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
          
          <div className="mb-8">
            <h3 className="text-xl font-semibold mb-4">Health Timeline</h3>
            <div className="relative pl-8 border-l-2 border-primary-200 space-y-8 py-4">
              {patient.medicalHistory.map((record, index) => (
                <div key={record.id} className={`relative animate-fadeIn animation-delay-${index}`}>
                  <div className="absolute -left-10 mt-1.5 w-4 h-4 rounded-full bg-primary-500"></div>
                  <div className="card mb-0 hover:shadow-lg transition-shadow">
                    <div className="flex justify-between mb-2">
                      <span className="text-neutral-500">{formatDate(record.date)}</span>
                      <span className="badge badge-primary">{record.condition}</span>
                    </div>
                    <h4 className="text-lg font-semibold mb-2">{record.provider}</h4>
                    <p className="text-neutral-700">{record.notes}</p>
                    {record.followUp && (
                      <div className="mt-4 pt-4 border-t border-neutral-200">
                        <div className="flex items-center text-sm">
                          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 text-primary-500">
                            <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                            <line x1="16" y1="2" x2="16" y2="6"></line>
                            <line x1="8" y1="2" x2="8" y2="6"></line>
                            <line x1="3" y1="10" x2="21" y2="10"></line>
                          </svg>
                          Follow-up: {formatDate(record.followUp)}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
      
      {activeTab === 'prescriptions' && (
        <div className="animate-fadeIn">
          <div className="flex justify-between mb-6">
            <h3 className="text-xl font-semibold">Prescriptions</h3>
            <button className="btn btn-primary">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                <line x1="12" y1="5" x2="12" y2="19"></line>
                <line x1="5" y1="12" x2="19" y2="12"></line>
              </svg>
              Prescribe Medication
            </button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {patient.prescriptions.map((prescription) => (
              <div key={prescription.id} className={`card transition-all hover:shadow-lg ${prescription.status === 'Active' ? '' : 'bg-neutral-50'}`}>
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-xl font-semibold">{prescription.medication}</h3>
                    <p className="text-neutral-500">{prescription.dosage} • {prescription.frequency}</p>
                  </div>
                  <span className={`badge ${prescription.status === 'Active' ? 'badge-success' : 'badge-secondary'}`}>
                    {prescription.status}
                  </span>
                </div>
                
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <p className="text-sm text-neutral-500">Start Date</p>
                    <p>{formatDate(prescription.startDate)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-neutral-500">End Date</p>
                    <p>{formatDate(prescription.endDate)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-neutral-500">Prescribed By</p>
                    <p>{prescription.prescribedBy}</p>
                  </div>
                  <div>
                    <p className="text-sm text-neutral-500">Refills</p>
                    <p>{prescription.refills} remaining</p>
                  </div>
                </div>
                
                {prescription.notes && (
                  <div className="p-3 bg-neutral-50 rounded-md text-sm">
                    <p className="font-medium mb-1">Instructions:</p>
                    <p>{prescription.notes}</p>
                  </div>
                )}
                
                <div className="mt-4 flex justify-end space-x-2">
                  {prescription.status === 'Active' && (
                    <button className="btn btn-sm btn-primary">Renew</button>
                  )}
                  <button className="btn btn-sm btn-outline">Edit</button>
                </div>
              </div>
            ))}
            
            {patient.prescriptions.length === 0 && (
              <div className="md:col-span-2 text-center py-12">
                <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mx-auto mb-4 text-neutral-400">
                  <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                  <line x1="9" y1="9" x2="15" y2="15"></line>
                  <line x1="15" y1="9" x2="9" y2="15"></line>
                </svg>
                <h3 className="text-xl font-medium mb-2">No Prescriptions</h3>
                <p className="text-neutral-500">This patient doesn't have any prescriptions in their record.</p>
              </div>
            )}
          </div>
        </div>
      )}
      
      {activeTab === 'lab' && (
        <div className="animate-fadeIn">
          <div className="flex justify-between mb-6">
            <h3 className="text-xl font-semibold">Lab Reports</h3>
            <button className="btn btn-primary">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                <line x1="12" y1="5" x2="12" y2="19"></line>
                <line x1="5" y1="12" x2="19" y2="12"></line>
              </svg>
              Order New Test
            </button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {patient.labReports.map((report) => (
              <div key={report.id} className="card hover:shadow-lg transition-shadow">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-lg font-semibold">{report.type}</h3>
                    <p className="text-sm text-neutral-500">{formatDate(report.date)}</p>
                  </div>
                  <button className="btn btn-sm btn-outline">View</button>
                </div>
                
                <div className="p-3 bg-neutral-50 rounded-md mb-4">
                  <p className="text-sm">{report.summary}</p>
                </div>
                
                <div>
                  <p className="text-sm text-neutral-500 mb-2">Ordered by</p>
                  <p className="font-medium">{report.orderedBy}</p>
                </div>
              </div>
            ))}
            
            {patient.labReports.length === 0 && (
              <div className="md:col-span-3 text-center py-12">
                <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mx-auto mb-4 text-neutral-400">
                  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                  <polyline points="14 2 14 8 20 8"></polyline>
                  <line x1="16" y1="13" x2="8" y2="13"></line>
                  <line x1="16" y1="17" x2="8" y2="17"></line>
                  <polyline points="10 9 9 9 8 9"></polyline>
                </svg>
                <h3 className="text-xl font-medium mb-2">No Lab Reports</h3>
                <p className="text-neutral-500">This patient doesn't have any lab reports in their record.</p>
              </div>
            )}
          </div>
        </div>
      )}
      
      {activeTab === 'appointments' && (
        <div className="animate-fadeIn">
          <div className="flex justify-between mb-6">
            <h3 className="text-xl font-semibold">Appointments</h3>
            <button className="btn btn-primary">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                <line x1="12" y1="5" x2="12" y2="19"></line>
                <line x1="5" y1="12" x2="19" y2="12"></line>
              </svg>
              Schedule New
            </button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="card">
              <h4 className="text-lg font-semibold mb-4">Upcoming Appointments</h4>
              <div className="space-y-4">
                {patient.appointments.filter(a => a.status === 'Scheduled').map((appointment) => (
                  <div key={appointment.id} className="p-4 border border-neutral-200 rounded-lg hover:border-primary-300 transition-colors">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-medium">{appointment.reason}</p>
                        <p className="text-sm text-neutral-500">
                          {formatDate(appointment.date)} • {appointment.time}
                        </p>
                      </div>
                      <span className="badge badge-primary">{appointment.type}</span>
                    </div>
                    <p className="text-sm mt-2">{appointment.location}</p>
                    <div className="mt-3 flex justify-end space-x-2">
                      <button className="btn btn-sm btn-outline">Reschedule</button>
                      <button className="btn btn-sm btn-primary">Start Visit</button>
                    </div>
                  </div>
                ))}
                
                {patient.appointments.filter(a => a.status === 'Scheduled').length === 0 && (
                  <div className="text-center py-6 text-neutral-500">
                    No upcoming appointments scheduled
                  </div>
                )}
              </div>
            </div>
            
            <div className="card">
              <h4 className="text-lg font-semibold mb-4">Past Appointments</h4>
              <div className="space-y-4">
                {patient.appointments.filter(a => a.status === 'Completed').map((appointment) => (
                  <div key={appointment.id} className="p-4 border border-neutral-200 rounded-lg bg-neutral-50">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-medium">{appointment.reason}</p>
                        <p className="text-sm text-neutral-500">
                          {formatDate(appointment.date)} • {appointment.time}
                        </p>
                      </div>
                      <span className="badge badge-secondary">Completed</span>
                    </div>
                    {appointment.notes && (
                      <div className="mt-3 text-sm">
                        <p className="text-neutral-600 italic">{appointment.notes}</p>
                      </div>
                    )}
                    <div className="mt-3 flex justify-end">
                      <button className="btn btn-sm btn-outline">View Details</button>
                    </div>
                  </div>
                ))}
                
                {patient.appointments.filter(a => a.status === 'Completed').length === 0 && (
                  <div className="text-center py-6 text-neutral-500">
                    No past appointments
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PatientDetail;