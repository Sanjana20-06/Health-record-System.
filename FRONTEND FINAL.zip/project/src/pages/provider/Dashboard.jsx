import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext.jsx';
import StatCard from '../../components/dashboard/StatCard.jsx';
import AppointmentList from '../../components/dashboard/AppointmentList.jsx';
import { appointments, patients } from '../../data/mockData.js';
import { format } from 'date-fns';

const ProviderDashboard = () => {
  const { currentUser } = useAuth();
  const [loading, setLoading] = useState(true);
  const [upcomingAppointmentsCount, setUpcomingAppointmentsCount] = useState(0);
  const [messagesCount, setMessagesCount] = useState(0);
  
  useEffect(() => {
    // Simulate loading data
    const timer = setTimeout(() => {
      setLoading(false);
      setUpcomingAppointmentsCount(
        appointments.filter(a => a.status === 'Scheduled').length
      );
      setMessagesCount(2); // Mock unread messages count
    }, 1000);
    
    return () => clearTimeout(timer);
  }, []);
  
  const today = new Date();
  
  if (loading) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="text-center">
          <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="animate-spin text-primary-500 mx-auto mb-4">
            <circle cx="12" cy="12" r="10"></circle>
            <path d="M12 6v6l4 2"></path>
          </svg>
          <p className="text-neutral-600">Loading your provider dashboard...</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="animate-fadeIn">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Hi, Dr. {currentUser.lastName}!</h1>
        <p className="text-neutral-600">
          Welcome to your provider dashboard. Here's your overview for {format(today, 'MMMM d, yyyy')}.
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard 
          title="Total Patients" 
          value={patients.length}
          icon={
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
              <circle cx="9" cy="7" r="4"></circle>
              <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
              <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
            </svg>
          }
          color="primary"
        />
        
        <StatCard 
          title="Upcoming Appointments" 
          value={upcomingAppointmentsCount}
          icon={
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
              <line x1="16" y1="2" x2="16" y2="6"></line>
              <line x1="8" y1="2" x2="8" y2="6"></line>
              <line x1="3" y1="10" x2="21" y2="10"></line>
            </svg>
          }
          color="secondary"
        />
        
        <StatCard 
          title="Unread Messages" 
          value={messagesCount}
          icon={
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
              <polyline points="22,6 12,13 2,6"></polyline>
            </svg>
          }
          color="warning"
        />
        
        <StatCard 
          title="Today's Appointments" 
          value="2"
          icon={
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="10"></circle>
              <polyline points="12 6 12 12 16 14"></polyline>
            </svg>
          }
          color="success"
        />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div className="lg:col-span-2">
          <AppointmentList appointments={appointments} />
        </div>
        
        <div className="card">
          <h3 className="text-xl font-semibold mb-6">Recent Patients</h3>
          <div className="space-y-4">
            {patients.map(patient => (
              <Link 
                key={patient.id}
                to={`/patients/${patient.id}`}
                className="flex items-center p-3 border border-neutral-200 rounded-lg hover:bg-neutral-50 transition-colors"
              >
                <div className="avatar avatar-md mr-3">
                  <span>
                    {patient.firstName.charAt(0)}
                    {patient.lastName.charAt(0)}
                  </span>
                </div>
                <div>
                  <h4 className="font-medium">{patient.firstName} {patient.lastName}</h4>
                  <p className="text-sm text-neutral-500">
                    {format(new Date(patient.dateOfBirth), 'MMM d, yyyy')} • {patient.conditions.join(', ')}
                  </p>
                </div>
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="ml-auto text-neutral-400">
                  <polyline points="9 18 15 12 9 6"></polyline>
                </svg>
              </Link>
            ))}
          </div>
          <div className="mt-6 text-center">
            <Link to="/patients" className="btn btn-outline">
              View All Patients
            </Link>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="card">
          <h3 className="text-xl font-semibold mb-4">Tasks</h3>
          <div className="space-y-3">
            <div className="flex items-center">
              <input type="checkbox" className="mr-3 h-5 w-5" />
              <span>Review lab results for Michael Brown</span>
              <span className="ml-auto badge badge-warning">Priority</span>
            </div>
            <div className="flex items-center">
              <input type="checkbox" className="mr-3 h-5 w-5" />
              <span>Call pharmacy about prescription refill</span>
            </div>
            <div className="flex items-center">
              <input type="checkbox" className="mr-3 h-5 w-5" />
              <span>Update treatment plan for Emma Wilson</span>
            </div>
            <div className="flex items-center">
              <input type="checkbox" className="mr-3 h-5 w-5" />
              <span>Schedule follow-up with John Doe</span>
            </div>
            <div className="flex items-center">
              <input type="checkbox" className="mr-3 h-5 w-5" />
              <span>Complete medical certification form</span>
            </div>
          </div>
          <div className="mt-4 pt-4 border-t border-neutral-200 flex justify-between items-center">
            <button className="text-sm text-primary-500">+ Add Task</button>
            <button className="text-sm text-neutral-500">View All</button>
          </div>
        </div>
        
        <div className="card">
          <h3 className="text-xl font-semibold mb-4">Recent Messages</h3>
          <div className="space-y-4">
            <div className="p-4 border border-neutral-200 rounded-lg bg-primary-50 relative">
              <div className="absolute top-4 right-4 w-2 h-2 bg-primary-500 rounded-full"></div>
              <div className="flex items-center mb-2">
                <div className="avatar avatar-sm mr-2">
                  <span>JD</span>
                </div>
                <div>
                  <h4 className="font-medium">John Doe</h4>
                  <p className="text-xs text-neutral-500">Today, 2:30 PM</p>
                </div>
              </div>
              <p className="text-sm">
                The dizziness has improved significantly since taking the medication at night. Thanks for the advice!
              </p>
            </div>
            
            <div className="p-4 border border-neutral-200 rounded-lg bg-primary-50 relative">
              <div className="absolute top-4 right-4 w-2 h-2 bg-primary-500 rounded-full"></div>
              <div className="flex items-center mb-2">
                <div className="avatar avatar-sm mr-2">
                  <span>EW</span>
                </div>
                <div>
                  <h4 className="font-medium">Emma Wilson</h4>
                  <p className="text-xs text-neutral-500">Yesterday, 4:15 PM</p>
                </div>
              </div>
              <p className="text-sm">
                I'm having trouble with the new inhaler prescription. Can we discuss alternatives?
              </p>
            </div>
          </div>
          <div className="mt-4 text-center">
            <Link to="/messages" className="btn btn-primary">
              View All Messages
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProviderDashboard;