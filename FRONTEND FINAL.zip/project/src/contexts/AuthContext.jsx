import { createContext, useState, useContext, useEffect } from 'react';

// Create the auth context
const AuthContext = createContext();

// Mock data for demonstration
const mockUsers = [
  {
    id: '1',
    email: 'patient@example.com',
    password: 'password123',
    firstName: 'John',
    lastName: 'Doe',
    role: 'patient',
    dateOfBirth: '1985-05-15',
    profileImage: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=150'
  },
  {
    id: '2',
    email: 'doctor@example.com',
    password: 'password123',
    firstName: 'Sarah',
    lastName: 'Johnson',
    role: 'provider',
    specialty: 'Cardiology',
    profileImage: 'https://images.pexels.com/photos/5452201/pexels-photo-5452201.jpeg?auto=compress&cs=tinysrgb&w=150'
  }
];

export const AuthProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    // Check for user in localStorage on initial load
    const storedUser = localStorage.getItem('healthRecordsUser');
    if (storedUser) {
      setCurrentUser(JSON.parse(storedUser));
    }
    setLoading(false);
  }, []);

  const login = (email, password) => {
    try {
      setError('');
      const user = mockUsers.find(
        (user) => user.email === email && user.password === password
      );
      
      if (!user) {
        throw new Error('Invalid email or password');
      }
      
      // Remove password before storing
      const { password: _, ...userWithoutPassword } = user;
      setCurrentUser(userWithoutPassword);
      localStorage.setItem('healthRecordsUser', JSON.stringify(userWithoutPassword));
      return userWithoutPassword;
    } catch (err) {
      setError(err.message);
      throw err;
    }
  };

  const register = (userData) => {
    try {
      setError('');
      // Check if email already exists
      if (mockUsers.some((user) => user.email === userData.email)) {
        throw new Error('Email already in use');
      }
      
      // In a real app, we would send this data to an API
      // For demo purposes, we'll just set the user directly
      const newUser = {
        id: Date.now().toString(),
        ...userData
      };
      
      // Remove password before storing in state
      const { password: _, ...userWithoutPassword } = newUser;
      setCurrentUser(userWithoutPassword);
      localStorage.setItem('healthRecordsUser', JSON.stringify(userWithoutPassword));
      return userWithoutPassword;
    } catch (err) {
      setError(err.message);
      throw err;
    }
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem('healthRecordsUser');
  };

  const forgotPassword = (email) => {
    try {
      setError('');
      const user = mockUsers.find((user) => user.email === email);
      if (!user) {
        throw new Error('No account found with that email');
      }
      
      // In a real app, we would send a reset email
      // For demo purposes, we'll just return success
      return true;
    } catch (err) {
      setError(err.message);
      throw err;
    }
  };

  const updateProfile = (updates) => {
    try {
      if (!currentUser) {
        throw new Error('No user logged in');
      }
      
      const updatedUser = { ...currentUser, ...updates };
      setCurrentUser(updatedUser);
      localStorage.setItem('healthRecordsUser', JSON.stringify(updatedUser));
      return updatedUser;
    } catch (err) {
      setError(err.message);
      throw err;
    }
  };

  const value = {
    currentUser,
    login,
    register,
    logout,
    forgotPassword,
    updateProfile,
    error,
    loading
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  return useContext(AuthContext);
};

export default AuthContext;